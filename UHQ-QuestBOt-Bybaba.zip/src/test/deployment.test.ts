
import { config as dotenv } from "dotenv";
dotenv();
type TestFn = () => Promise<void> | void;
const results: { name: string; ok: boolean; err?: string }[] = [];

async function test(name: string, fn: TestFn) {
  try {
    await fn();
    results.push({ name, ok: true });
    console.log(`  ✅ ${name}`);
  } catch (e: any) {
    results.push({ name, ok: false, err: e?.message ?? String(e) });
    console.log(`  ❌ ${name}\n     → ${e?.message ?? e}`);
  }
}

function assert(cond: boolean, msg: string) {
  if (!cond) throw new Error(msg);
}
console.log("\n📋 Environment");
await test("DATABASE_TYPE set", () => assert(!!process.env.DATABASE_TYPE, "DATABASE_TYPE missing from .env"));
await test("DATABASE_URL set",  () => assert(!!process.env.DATABASE_URL,  "DATABASE_URL missing from .env"));
await test("SESSION_SECRET set", () => {
  const s = process.env.SESSION_SECRET ?? "";
  assert(s.length >= 12, "SESSION_SECRET too short (min 12 chars)");
  assert(s !== "questy-sadie-sink-secret", "SESSION_SECRET is still the default — change it");
});
await test("DISCORD_CLIENT_ID set",     () => assert(!!process.env.DISCORD_CLIENT_ID,     "DISCORD_CLIENT_ID missing"));
await test("DISCORD_CLIENT_SECRET set", () => assert(!!process.env.DISCORD_CLIENT_SECRET, "DISCORD_CLIENT_SECRET missing"));
console.log("\n🔐 Encryption");
const { encrypt, decrypt } = await import("../core/encryption.js");

await test("encrypt returns non-empty string", () => {
  const c = encrypt("hello");
  assert(c.length > 10, "cipher too short");
  assert(c !== "hello",  "cipher equals plain — not encrypted");
});
await test("decrypt(encrypt(x)) === x", () => {
  const plain  = "MTExMTExMTExMTEx.abc.xyz";
  const round  = decrypt(encrypt(plain));
  assert(round === plain, `round-trip mismatch: "${round}" !== "${plain}"`);
});
await test("two encryptions of same plaintext differ (IV randomness)", () => {
  const a = encrypt("same"), b = encrypt("same");
  assert(a !== b, "deterministic encryption — IV not random");
});
console.log("\n🗄️  Database");
import { initializeDatabase } from "../providers/appDataSource.js";

let ds: any;
await test("database initialises", async () => {
  ds = await initializeDatabase();
  assert(ds.isInitialized, "DataSource not initialized after init()");
});

await test("all entities registered", () => {
  const names = ds.entityMetadatas.map((m: any) => m.tableName);
  const required = ["token_profiles", "premium_users", "key_store", "blacklist_store", "autoquest_store", "sessions"];
  const missing  = required.filter(n => !names.includes(n));
  assert(missing.length === 0, `missing tables: ${missing.join(", ")}`);
});
console.log("\n🪙  TokenStore");
const { addProfile, getProfiles, removeProfile, mask, hydrateTokenStore, MAX_PROFILES } = await import("../core/tokenStore.js");
await hydrateTokenStore();

const TEST_OWNER = "TEST_OWNER_000000000";
const pre = getProfiles(TEST_OWNER);
for (const p of pre) removeProfile(TEST_OWNER, p.id);

const FAKE_TOKEN = "MTExMTExMTExMTExMTEx.abc123.xyzxyzxyzxyzxyzxyzxyzxyz"; // realistic shape

await test("addProfile returns ok:true", () => {
  const r = addProfile(TEST_OWNER, FAKE_TOKEN);
  assert(r.ok === true, r.error ?? "unknown error");
});
await test("getProfiles returns 1 profile", () => {
  const p = getProfiles(TEST_OWNER);
  assert(p.length === 1, `expected 1 got ${p.length}`);
});
await test("duplicate token rejected", () => {
  const r = addProfile(TEST_OWNER, FAKE_TOKEN);
  assert(!r.ok, "should have rejected duplicate");
});
await test("mask hides token middle", () => {
  const m = mask(FAKE_TOKEN);
  assert(m.includes("..."), "mask missing ellipsis");
  assert(!m.includes(FAKE_TOKEN), "mask leaks full token");
});
await test("removeProfile works", () => {
  const p  = getProfiles(TEST_OWNER)[0];
  const ok = removeProfile(TEST_OWNER, p.id);
  assert(ok, "removeProfile returned false");
  assert(getProfiles(TEST_OWNER).length === 0, "profile still in cache after remove");
});
await test("MAX_PROFILES slot enforcement", () => {
  for (let i = 0; i < MAX_PROFILES; i++) {
    const id = `11111111111111111${i}`;
    const b64 = Buffer.from(id).toString("base64").replace(/=+$/, "");
    const tok = `${b64}.abc123.xyzxyzxyzxyzxyzxyzxyzxyz${i}`;
    addProfile(TEST_OWNER, tok);
  }
  const overflowId = "99999999999999999";
  const b64 = Buffer.from(overflowId).toString("base64").replace(/=+$/, "");
  const tok = `${b64}.abc123.overflow`;
  const r = addProfile(TEST_OWNER, tok);
  assert(!r.ok, "should have rejected overflow token");
  const list = getProfiles(TEST_OWNER);
  for (const p of list) removeProfile(TEST_OWNER, p.id);
});
console.log("\n⭐  Stores");
const { premium, keys, blacklist, autoQuest, isPremium, genKey, hydrateStores } = await import("../core/stores.js");
await hydrateStores();

const TEST_USER = "TEST_USER_999999999";

await test("premium: set → isPremium true", () => {
  premium.set(TEST_USER, { since: Date.now(), until: Date.now() + 3600_000 });
  assert(isPremium(TEST_USER), "should be premium");
});
await test("premium: delete → isPremium false", () => {
  premium.delete(TEST_USER);
  assert(!isPremium(TEST_USER), "should not be premium after delete");
});
await test("premium: expired → isPremium false", () => {
  premium.set(TEST_USER, { since: Date.now() - 2000, until: Date.now() - 1000 });
  assert(!isPremium(TEST_USER), "expired premium should return false");
  premium.delete(TEST_USER);
});

await test("keys: genKey format", () => {
  const k = genKey();
  assert(k.startsWith("QUESTY-"), "key missing QUESTY- prefix");
  assert(k.length > 14, "key too short");
});
await test("keys: set and get", () => {
  const k = genKey();
  keys.set(k, { key: k, days: 30, createdBy: "TEST", createdAt: Date.now() });
  assert(keys.has(k), "key not found after set");
  keys.delete(k);
  assert(!keys.has(k), "key still present after delete");
});

await test("blacklist: set and check", () => {
  blacklist.set(TEST_USER, { reason: "test", at: Date.now() });
  assert(blacklist.has(TEST_USER), "should be blacklisted");
  blacklist.delete(TEST_USER);
  assert(!blacklist.has(TEST_USER), "should not be blacklisted after delete");
});

await test("autoQuest: add and delete", () => {
  autoQuest.add(TEST_USER);
  assert(autoQuest.has(TEST_USER), "should be in autoQuest");
  autoQuest.delete(TEST_USER);
  assert(!autoQuest.has(TEST_USER), "should not be in autoQuest after delete");
});
console.log("\n💾  Session Store");
const { TypeORMSessionStore } = await import("../core/sessionStore.js");

await test("TypeORMSessionStore: set → get roundtrip", async () => {
  const store = new TypeORMSessionStore();
  const sid   = "test-session-" + Date.now();
  const sess  = { user: { id: "123", username: "testuser" }, cookie: { maxAge: 3600_000 } };
  await new Promise<void>((res, rej) => store.set(sid, sess, e => e ? rej(e) : res()));
  const back  = await new Promise<any>((res, rej) => store.get(sid, (e, s) => e ? rej(e) : res(s)));
  assert(back?.user?.id === "123", "session user ID mismatch after roundtrip");
  await new Promise<void>((res, rej) => store.destroy(sid, e => e ? rej(e) : res()));
});

await test("TypeORMSessionStore: destroy removes session", async () => {
  const store = new TypeORMSessionStore();
  const sid   = "del-test-" + Date.now();
  await new Promise<void>((res, rej) => store.set(sid, { cookie: { maxAge: 3600_000 } }, e => e ? rej(e) : res()));
  await new Promise<void>((res, rej) => store.destroy(sid, e => e ? rej(e) : res()));
  const back  = await new Promise<any>((res, rej) => store.get(sid, (e, s) => e ? rej(e) : res(s)));
  assert(!back, "session still returned after destroy");
});
console.log("\n🌐  API");
const port = Number(process.env.TEST_PORT || 13001);
import express from "express";
import session from "express-session";
import { authRouter } from "../api/auth.js";

const testApp = express();
testApp.use(express.json());
testApp.use(session({
  secret: process.env.SESSION_SECRET || "test",
  resave: false, saveUninitialized: false,
}));
testApp.use("/auth", authRouter);
testApp.get("/api/health",  (_, res) => res.json({ ok: true }));
testApp.get("/api/tokens",  (req: any, res) => {
  if (!req.session?.user) return res.status(401).json({ error: "Not authenticated" });
  res.json({ profiles: getProfiles(req.session.user.id), slots: 0, maxSlots: 3 });
});

const server = testApp.listen(port);
const BASE   = `http://localhost:${port}`;

await test("GET /api/health → 200 ok:true", async () => {
  const r = await fetch(`${BASE}/api/health`).then(x => x.json());
  assert(r.ok === true, `expected ok:true got ${JSON.stringify(r)}`);
});

await test("GET /auth/me without session → 401", async () => {
  const r = await fetch(`${BASE}/auth/me`);
  assert(r.status === 401, `expected 401 got ${r.status}`);
});

await test("GET /api/tokens without session → 401", async () => {
  const r = await fetch(`${BASE}/api/tokens`);
  assert(r.status === 401, `expected 401 got ${r.status}`);
});

await test("GET /auth/discord redirects to Discord OAuth URL", async () => {
  if (!process.env.DISCORD_CLIENT_ID) { console.log("     (skip — DISCORD_CLIENT_ID not set)"); return; }
  const r = await fetch(`${BASE}/auth/discord`, { redirect: "manual" });
  assert(r.status === 302, `expected 302 redirect got ${r.status}`);
  assert(r.headers.get("location")?.includes("discord.com"), "redirect not pointing to discord.com");
});

server.close();
console.log("\n🔄  Persistence Roundtrip");

await test("tokenStore: write → re-hydrate → read", async () => {
  const OWNER = "PERSIST_TEST_USER_1111";
  const id    = "11111111111111110"; // fake numeric Discord ID
  const b64   = Buffer.from(id).toString("base64").replace(/=+$/, "");
  const tok   = `${b64}.abc123.persisttesttoken`;

  addProfile(OWNER, tok);
  assert(getProfiles(OWNER).length >= 1, "profile not in cache");
  const { cache: _c } = await import("../core/tokenStore.js") as any;
  const { AppDataSource } = await import("../providers/appDataSource.js");
  const { TokenProfileEntity } = await import("../entities/tokenProfile.js");
  await new Promise(r => setTimeout(r, 300)); // let async persist settle
  const row = await AppDataSource.getRepo(TokenProfileEntity).findOne({ where: { ownerDiscordId: OWNER } }) as any;
  assert(!!row, "row not found in DB after addProfile");
  assert(row.accountDiscordId === id, `stored ID mismatch: ${row.accountDiscordId}`);
  removeProfile(OWNER, id);
  await new Promise(r => setTimeout(r, 200));
  const gone = await AppDataSource.getRepo(TokenProfileEntity).findOne({ where: { ownerDiscordId: OWNER } });
  assert(!gone, "row not deleted from DB after removeProfile");
});

await test("stores: premium write → DB row exists", async () => {
  const uid = "PERSIST_PREMIUM_TEST_2222";
  premium.set(uid, { since: Date.now(), until: Date.now() + 3_600_000 });
  await new Promise(r => setTimeout(r, 300));
  const { AppDataSource } = await import("../providers/appDataSource.js");
  const { PremiumEntity }  = await import("../entities/premiumStore.js");
  const row = await AppDataSource.getRepo(PremiumEntity).findOne({ where: { userId: uid } }) as any;
  assert(!!row, "premium row not found in DB");
  assert(Number(row.until) > Date.now(), "stored until is in the past");
  premium.delete(uid);
  await new Promise(r => setTimeout(r, 200));
  const gone = await AppDataSource.getRepo(PremiumEntity).findOne({ where: { userId: uid } });
  assert(!gone, "premium row not cleaned up");
});
console.log("\n" + "═".repeat(50));
const passed = results.filter(r => r.ok).length;
const failed = results.filter(r => !r.ok).length;
console.log(`  Total: ${results.length}  ✅ ${passed}  ❌ ${failed}`);

if (failed > 0) {
  console.log("\n  Failed tests:");
  results.filter(r => !r.ok).forEach(r => console.log(`  • ${r.name}\n    ${r.err}`));
  process.exit(1);
} else {
  console.log("\n  ✨ All tests passed — deployment ready.\n");
  process.exit(0);
}
