
import GuildDocument from "../entities/guildSettings.js";
import ImageEntity from "../entities/image.js";
import QuestEntity from "../entities/quests.js";
import UserDocument from "../entities/userSettings.js";
import { customCollection } from "../lib/handler/customCollection.js";
import { User } from "../lib/quest/User.js";

export const usersCache = new customCollection<string, User>();
export const questsCache = new customCollection<string, QuestEntity>();

function getApp(): any { try { return (global as any).AppDataSource || null; } catch { return null; } }
function lazyRepo(entity: any) {
  return new Proxy({}, {
    get(_, prop) {
      const app = getApp();
      if (!app || !app.getRepo) return (..._a:any[]) => Promise.resolve(prop==="find"?[]:null);
      const repo = app.getRepo(entity);
      const v = (repo as any)[prop];
      return typeof v==="function" ? v.bind(repo) : v;
    }
  }) as any;
}

export const guildSettingsRepo = lazyRepo(GuildDocument);
export const userSettingsRepo = lazyRepo(UserDocument);
export const imageRepo = lazyRepo(ImageEntity);
export const questRepo = lazyRepo(QuestEntity);