
import { encrypt, decrypt } from "./encryption.js";
import { Logger } from "./logger.js";

export type TokenProfile = {
  token:     string;
  id:        string;
  username?: string;
  addedAt:   number;
  valid?:    boolean;
};

export const MAX_PROFILES = 3;
const cache = new Map<string, TokenProfile[]>();
function extractIdFromToken(raw: string): string | null {
  try {
    const token  = raw.trim();
    const prefix = token.split(".")[0];
    const padded = prefix + "=".repeat((4 - prefix.length % 4) % 4);
    const id     = Buffer.from(padded, "base64").toString("utf8");
    return /^\d{17,20}$/.test(id) ? id : null;
  } catch { return null; }
}

function cleanRaw(raw: string): string {
  const m = raw.trim().match(/[A-Za-z0-9_-]{24,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{20,}/);
  return m ? m[0] : raw.trim();
}
async function getRepo() {
  try {
    const { AppDataSource } = await import("../providers/appDataSource.js");
    if (!AppDataSource?.isInitialized) return null;
    const { TokenProfileEntity } = await import("../entities/tokenProfile.js");
    return AppDataSource.getRepo(TokenProfileEntity) as any;
  } catch { return null; }
}
export async function hydrateTokenStore(): Promise<void> {
  const r = await getRepo();
  if (!r) { Logger.warn("tokenStore: DB not ready, skipping hydration"); return; }
  try {
    const rows: any[] = await r.find();
    for (const row of rows) {
      const list = cache.get(row.ownerDiscordId) ?? [];
      if (!list.find((p: TokenProfile) => p.id === row.accountDiscordId)) {
        list.push({
          token:    decrypt(row.encryptedToken),
          id:       row.accountDiscordId,
          username: row.username ?? undefined,
          addedAt:  Number(row.addedAt),
          valid:    row.valid,
        });
        cache.set(row.ownerDiscordId, list);
      }
    }
    Logger.info(`tokenStore: hydrated ${rows.length} token profiles from DB`);
  } catch (e: any) {
    Logger.warn("tokenStore: hydration failed — " + e.message);
  }
}
async function persistProfile(ownerDiscordId: string, p: TokenProfile): Promise<void> {
  const r = await getRepo();
  if (!r) return;
  try {
    const { TokenProfileEntity } = await import("../entities/tokenProfile.js");
    const existing = await r.findOne({ where: { ownerDiscordId, accountDiscordId: p.id } });
    if (existing) {
      existing.encryptedToken = encrypt(p.token);
      existing.username       = p.username;
      existing.valid          = p.valid ?? true;
      await r.save(existing);
    } else {
      const ent: any          = new TokenProfileEntity();
      ent.ownerDiscordId      = ownerDiscordId;
      ent.accountDiscordId    = p.id;
      ent.encryptedToken      = encrypt(p.token);
      ent.username            = p.username;
      ent.valid               = p.valid ?? true;
      ent.addedAt             = p.addedAt;
      await r.save(ent);
    }
  } catch (e: any) {
    Logger.warn("tokenStore: persist failed — " + e.message);
  }
}
async function deleteFromDB(ownerDiscordId: string, accountDiscordId: string): Promise<void> {
  const r = await getRepo();
  if (!r) return;
  try { await r.delete({ ownerDiscordId, accountDiscordId }); }
  catch (e: any) { Logger.warn("tokenStore: delete failed — " + e.message); }
}
export function getProfiles(ownerDiscordId: string): TokenProfile[] {
  return cache.get(ownerDiscordId) ?? [];
}

export function addProfile(
  ownerDiscordId: string,
  raw: string
): { ok: boolean; error?: string; profile?: TokenProfile } {
  const token = cleanRaw(raw);
  const id    = extractIdFromToken(token);

  if (!id) return { ok: false, error: "invalid token — could not extract user ID" };

  const list = getProfiles(ownerDiscordId);
  if (list.some(p => p.id === id))   return { ok: false, error: "token already connected" };
  if (list.length >= MAX_PROFILES)   return { ok: false, error: `all ${MAX_PROFILES} slots used — disconnect one first` };

  const p: TokenProfile = { token, id, addedAt: Date.now(), valid: true };
  const next = [...list, p];
  cache.set(ownerDiscordId, next);
  persistProfile(ownerDiscordId, p).catch(() => null);
  return { ok: true, profile: p };
}

export function removeProfile(ownerDiscordId: string, accountDiscordId: string): boolean {
  const list = getProfiles(ownerDiscordId);
  const next = list.filter(p => p.id !== accountDiscordId);
  if (next.length === list.length) return false;
  cache.set(ownerDiscordId, next);
  deleteFromDB(ownerDiscordId, accountDiscordId).catch(() => null);
  return true;
}

export async function validateProfile(p: TokenProfile): Promise<boolean> {
  try {
    const { check_token } = await import("../utils/quest/tokenUtils.js");
    const ok = await (check_token as any)(p.token);
    p.valid = !!ok;
    if (ok && typeof ok === "object" && (ok as any).username) p.username = (ok as any).username;
    return p.valid;
  } catch { p.valid = false; return false; }
}

export function mask(t: string): string {
  if (!t || t.length < 12) return "***";
  return t.slice(0, 6) + "..." + t.slice(-6);
}
