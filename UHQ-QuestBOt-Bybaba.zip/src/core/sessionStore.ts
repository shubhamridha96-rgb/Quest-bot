import { Store } from "express-session";
import { Logger } from "./logger.js";

export class TypeORMSessionStore extends Store {
  private cleanupInterval: NodeJS.Timeout | null = null;

  private async repo() {
    try {
      const { AppDataSource } = await import("../providers/appDataSource.js");
      if (!AppDataSource?.isInitialized) return null;
      const { SessionEntity } = await import("../entities/session.js");
      return AppDataSource.getRepo(SessionEntity) as any;
    } catch { return null; }
  }

  constructor() {
    super();
    this.cleanupInterval = setInterval(() => this.cleanup(), 15 * 60 * 1000);
    if (this.cleanupInterval?.unref) this.cleanupInterval.unref();
  }

  private async cleanup() {
    const r = await this.repo();
    if (!r) return;
    try {
      await r.createQueryBuilder()
        .delete()
        .where("expiresAt < :now", { now: Date.now() })
        .execute();
    } catch (e: any) {
      Logger.warn("session cleanup failed: " + e.message);
    }
  }

  get(sid: string, cb: (err: any, session?: any) => void) {
    this.repo()
      .then(r => {
        if (!r) return cb(null, null);
        return r.findOne({ where: { sid } }).then((row: any) => {
          if (!row || row.expiresAt < Date.now()) return cb(null, null);
          try { cb(null, JSON.parse(row.data)); } catch { cb(null, null); }
        });
      })
      .catch(cb);
  }

  set(sid: string, session: any, cb?: (err?: any) => void) {
    const maxAge    = session?.cookie?.maxAge ?? 7 * 24 * 3600 * 1000;
    const expiresAt = Date.now() + maxAge;
    const data      = JSON.stringify(session);
    this.repo()
      .then(async r => {
        if (!r) return cb?.();
        const { SessionEntity } = await import("../entities/session.js");
        const existing = await r.findOne({ where: { sid } });
        if (existing) {
          existing.data = data; existing.expiresAt = expiresAt;
          await r.save(existing);
        } else {
          const e: any = new SessionEntity();
          e.sid = sid; e.data = data; e.expiresAt = expiresAt;
          await r.save(e);
        }
        cb?.();
      })
      .catch(cb);
  }

  destroy(sid: string, cb?: (err?: any) => void) {
    this.repo()
      .then(r => { if (!r) return cb?.(); return r.delete({ sid }).then(() => cb?.()); })
      .catch(cb);
  }

  touch(sid: string, session: any, cb?: (err?: any) => void) {
    this.set(sid, session, cb);
  }
}
