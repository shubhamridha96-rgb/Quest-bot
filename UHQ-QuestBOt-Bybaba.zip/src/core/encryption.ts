import crypto from "crypto";
function deriveKey(): Buffer {
  const raw = process.env.TOKEN_ENCRYPTION_KEY || process.env.SESSION_SECRET || "questy-default-key-CHANGE-IN-PROD";
  return crypto.createHash("sha256").update(raw).digest();
}

const ALGO = "aes-256-gcm";

export function encrypt(plain: string): string {
  const key = deriveKey();
  const iv  = crypto.randomBytes(12);
  const c   = crypto.createCipheriv(ALGO, key, iv);
  const enc = Buffer.concat([c.update(plain, "utf8"), c.final()]);
  const tag = c.getAuthTag();
  return [iv.toString("hex"), tag.toString("hex"), enc.toString("hex")].join(":");
}

export function decrypt(blob: string): string {
  try {
    const [ivHex, tagHex, encHex] = blob.split(":");
    const key = deriveKey();
    const d   = crypto.createDecipheriv(ALGO, key, Buffer.from(ivHex, "hex"));
    d.setAuthTag(Buffer.from(tagHex, "hex"));
    return Buffer.concat([d.update(Buffer.from(encHex, "hex")), d.final()]).toString("utf8");
  } catch {
    return blob;
  }
}
