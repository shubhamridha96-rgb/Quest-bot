
import { Logger } from "./logger.js";
export const blacklist = new Map<string, { reason?: string; at: number }>();
export const premium   = new Map<string, { since: number; until: number }>();
export const keys      = new Map<string, { key: string; days: number; createdBy: string; usedBy?: string; createdAt: number }>();
export const autoQuest = new Set<string>();

export function isOwner(id: string, devs: string[])  { return devs.includes(id); }
export function isPremium(id: string)                 { const p = premium.get(id); return p ? p.until > Date.now() : false; }
export function genKey()                              { return "QUESTY-" + Math.random().toString(36).slice(2, 8).toUpperCase() + "-" + Math.random().toString(36).slice(2, 8).toUpperCase(); }
async function ds() {
  try {
    const { AppDataSource } = await import("../providers/appDataSource.js");
    return AppDataSource?.isInitialized ? AppDataSource : null;
  } catch { return null; }
}
export async function hydrateStores(): Promise<void> {
  const src = await ds();
  if (!src) return;
  try {
    const { PremiumEntity, KeyEntity, BlacklistEntity, AutoQuestEntity } = await import("../entities/premiumStore.js");

    const [premRows, keyRows, blRows, aqRows] = await Promise.all([
      src.getRepo(PremiumEntity).find(),
      src.getRepo(KeyEntity).find(),
      src.getRepo(BlacklistEntity).find(),
      src.getRepo(AutoQuestEntity).find(),
    ]);

    premRows.forEach((r: any) => premium.set(r.userId,   { since: Number(r.since), until: Number(r.until) }));
    keyRows.forEach((r: any)  => keys.set(r.key,         { key: r.key, days: r.days, createdBy: r.createdBy, usedBy: r.usedBy, createdAt: Number(r.createdAt) }));
    blRows.forEach((r: any)   => blacklist.set(r.userId, { reason: r.reason, at: Number(r.at) }));
    aqRows.forEach((r: any)   => autoQuest.add(r.userId));

    Logger.info(`stores: hydrated — ${premRows.length} premium, ${keyRows.length} keys, ${blRows.length} blacklist, ${aqRows.length} autoquest`);
  } catch (e: any) {
    Logger.warn("stores: hydration failed — " + e.message);
  }
}

const _premSet    = premium.set.bind(premium);
const _premDelete = premium.delete.bind(premium);
premium.set = (id: string, val: { since: number; until: number }) => {
  _premSet(id, val);
  persistPremium(id, val).catch(() => null);
  return premium;
};
premium.delete = (id: string) => {
  const r = _premDelete(id);
  deletePremium(id).catch(() => null);
  return r;
};

const _blSet    = blacklist.set.bind(blacklist);
const _blDelete = blacklist.delete.bind(blacklist);
blacklist.set = (id: string, val: { reason?: string; at: number }) => {
  _blSet(id, val);
  persistBlacklist(id, val).catch(() => null);
  return blacklist;
};
blacklist.delete = (id: string) => {
  const r = _blDelete(id);
  deleteBlacklist(id).catch(() => null);
  return r;
};

const _keysSet    = keys.set.bind(keys);
const _keysDelete = keys.delete.bind(keys);
keys.set = (k: string, val: any) => {
  _keysSet(k, val);
  persistKey(k, val).catch(() => null);
  return keys;
};
keys.delete = (k: string) => {
  const r = _keysDelete(k);
  deleteKey(k).catch(() => null);
  return r;
};

const _aqAdd    = autoQuest.add.bind(autoQuest);
const _aqDelete = autoQuest.delete.bind(autoQuest);
autoQuest.add = (id: string) => {
  _aqAdd(id);
  persistAutoQuest(id).catch(() => null);
  return autoQuest;
};
autoQuest.delete = (id: string) => {
  const r = _aqDelete(id);
  deleteAutoQuest(id).catch(() => null);
  return r;
};
async function persistPremium(userId: string, val: { since: number; until: number }) {
  const src = await ds(); if (!src) return;
  const { PremiumEntity } = await import("../entities/premiumStore.js");
  const r   = src.getRepo(PremiumEntity);
  const existing = await (r as any).findOne({ where: { userId } });
  if (existing) { existing.since = val.since; existing.until = val.until; await (r as any).save(existing); }
  else { const e = new PremiumEntity(); Object.assign(e, { userId, ...val }); await (r as any).save(e); }
}
async function deletePremium(userId: string) {
  const src = await ds(); if (!src) return;
  const { PremiumEntity } = await import("../entities/premiumStore.js");
  await src.getRepo(PremiumEntity).delete({ userId } as any);
}

async function persistBlacklist(userId: string, val: { reason?: string; at: number }) {
  const src = await ds(); if (!src) return;
  const { BlacklistEntity } = await import("../entities/premiumStore.js");
  const r = src.getRepo(BlacklistEntity);
  const existing = await (r as any).findOne({ where: { userId } });
  if (existing) { Object.assign(existing, val); await (r as any).save(existing); }
  else { const e = new BlacklistEntity(); Object.assign(e, { userId, ...val }); await (r as any).save(e); }
}
async function deleteBlacklist(userId: string) {
  const src = await ds(); if (!src) return;
  const { BlacklistEntity } = await import("../entities/premiumStore.js");
  await src.getRepo(BlacklistEntity).delete({ userId } as any);
}

async function persistKey(key: string, val: any) {
  const src = await ds(); if (!src) return;
  const { KeyEntity } = await import("../entities/premiumStore.js");
  const r = src.getRepo(KeyEntity);
  const existing = await (r as any).findOne({ where: { key } });
  if (existing) { Object.assign(existing, val); await (r as any).save(existing); }
  else { const e = new KeyEntity(); Object.assign(e, val); await (r as any).save(e); }
}
async function deleteKey(key: string) {
  const src = await ds(); if (!src) return;
  const { KeyEntity } = await import("../entities/premiumStore.js");
  await src.getRepo(KeyEntity).delete({ key } as any);
}

async function persistAutoQuest(userId: string) {
  const src = await ds(); if (!src) return;
  const { AutoQuestEntity } = await import("../entities/premiumStore.js");
  const r = src.getRepo(AutoQuestEntity);
  const existing = await (r as any).findOne({ where: { userId } });
  if (!existing) { const e = new AutoQuestEntity(); e.userId = userId; await (r as any).save(e); }
}
async function deleteAutoQuest(userId: string) {
  const src = await ds(); if (!src) return;
  const { AutoQuestEntity } = await import("../entities/premiumStore.js");
  await src.getRepo(AutoQuestEntity).delete({ userId } as any);
}
