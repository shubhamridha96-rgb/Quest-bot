const houses = ['bravery', 'brilliance', 'balance'] as const;
export type House = typeof houses[number];
export async function change_house(token:string, house:string): Promise<number>{
  if(!token||!house) return 0;
  house=house.toLowerCase() as House;
  if(!houses.includes(house as House)) return 0;
  const res=await fetch("https://discord.com/api/v9/hypesquad/online", {
    method:"POST",
    headers:{ "Authorization": token, "Content-Type":"application/json" },
    body: JSON.stringify({ house_id: houses.indexOf(house as House)+1 })
  });
  if(res.status===204) return 1;
  const txt=await res.text().catch(()=> "");
  if(res.status===401) throw new Error(`401 Unauthorized — token invalid/expired. Re-add fresh USER token via /connect-token (not bot token). ${txt}`);
  throw new Error(`Discord API ${res.status}: ${txt}`);
}
export { houses };
