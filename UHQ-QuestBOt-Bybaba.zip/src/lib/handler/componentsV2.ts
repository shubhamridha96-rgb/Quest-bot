import {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  SectionBuilder,
  ThumbnailBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  MessageFlags,
} from "discord.js";
import config from "../../config/config.js";
import { SadieTheme } from "../../config/theme.js";

function hexToInt(hex?: string | number | null): number | undefined {
  if (hex == null) return undefined;
  if (typeof hex === "number") return hex;
  let h = String(hex).trim().replace("#", "");
  if (/^[0-9A-Fa-f]{6}$/.test(h)) return parseInt(h, 16);
  return undefined;
}

export const V2_FLAG = MessageFlags.IsComponentsV2;
export const V2_EPHEMERAL_FLAG = MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral;

export function accentColor(color?: string | number | null): number {
  const c = hexToInt(color) ?? hexToInt(config.embedColor) ?? SadieTheme.colors.primary;
  return c;
}

export function text(content: string) {
  return new TextDisplayBuilder().setContent(content);
}

export function separator(small = true, divider = true) {
  return new SeparatorBuilder().setSpacing(small ? SeparatorSpacingSize.Small : SeparatorSpacingSize.Large).setDivider(divider);
}

export function containerWithText(content: string, color?: string | number | null) {
  const c = new ContainerBuilder().setAccentColor(accentColor(color ?? SadieTheme.colors.primaryHex));
  c.addTextDisplayComponents(text(content));
  c.addSeparatorComponents(separator());
  c.addTextDisplayComponents(text(`-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text} ${SadieTheme.emojis.max}`));
  return c;
}

export function simplePayload(content: string, color?: string | number | null, ephemeral = false) {
  return {
    components: [containerWithText(content, color)],
    flags: ephemeral ? V2_EPHEMERAL_FLAG : V2_FLAG,
  };
}

export function errorPayload(content: string, ephemeral = false) {
  return simplePayload(content, "DarkRed", ephemeral);
}

export function payloadFromContainers(containers: ContainerBuilder[], ephemeral = false) {
  return {
    components: containers,
    flags: ephemeral ? V2_EPHEMERAL_FLAG : V2_FLAG,
  };
}

export function buildQuestContainer(opts: {
  title?: string;
  description?: string;
  fields?: { name: string; value: string; inline?: boolean }[];
  thumbnail?: string | null;
  image?: string | null;
  footerText?: string;
  footerIcon?: string | null;
  timestamp?: Date | null;
  accentColor?: string | number | null;
  extraText?: string[];
}) {
  const c = new ContainerBuilder().setAccentColor(accentColor(opts.accentColor));
  if (opts.title) c.addTextDisplayComponents(text(`## ${opts.title}`));
  if (opts.description) c.addTextDisplayComponents(text(opts.description));
  if (opts.fields?.length) {
    for (const f of opts.fields) {
      c.addTextDisplayComponents(text(`**${f.name}**\n${f.value}`));
    }
  }
  if (opts.extraText?.length) {
    for (const t of opts.extraText) c.addTextDisplayComponents(text(t));
  }
  if (opts.thumbnail) {
    c.addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(text(opts.description || opts.title || ""))
        .setThumbnailAccessory(new ThumbnailBuilder().setDescription("thumbnail").setURL(opts.thumbnail))
    );
  }
  if (opts.image) {
    c.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setDescription("hero").setURL(opts.image))
    );
  }
  if (opts.footerText) {
    const ft = opts.timestamp ? `${opts.footerText} • <t:${Math.floor(opts.timestamp.getTime() / 1000)}:R>` : opts.footerText;
    c.addSeparatorComponents(separator());
    c.addTextDisplayComponents(text(`-# ${ft}`));
  } else if (opts.timestamp) {
    c.addTextDisplayComponents(text(`-# <t:${Math.floor(opts.timestamp.getTime() / 1000)}:R>`));
  }
  return c;
}

export function createV2ContainerWithSections(opts: {
  accentColor?: number | string | null;
  title?: string;
  descriptionBlock?: string;
  fieldsInline?: { name: string; value: string }[];
  image?: string | null;
  thumbnail?: string | null;
  footer?: string | null;
  footerIcon?: string | null;
  timestamp?: Date | null;
  extraBlocks?: string[];
}) {
  const acc = accentColor(opts.accentColor);
  const container = new ContainerBuilder().setAccentColor(acc);
  if (opts.title) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${opts.title}`));
  if (opts.thumbnail) {
    const sec = new SectionBuilder()
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(opts.descriptionBlock || ""))
      .setThumbnailAccessory(new ThumbnailBuilder().setDescription("thumb").setURL(opts.thumbnail));
    container.addSectionComponents(sec);
  } else if (opts.descriptionBlock) {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(opts.descriptionBlock));
  }
  if (opts.fieldsInline?.length) {
    const fieldLines = opts.fieldsInline.map(f => `**${f.name}** ${f.value}`).join("\n");
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(fieldLines));
  }
  if (opts.extraBlocks?.length) {
    for (const b of opts.extraBlocks) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(b));
  }
  if (opts.image) {
    container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setDescription("image").setURL(opts.image)));
  }
  if (opts.footer || opts.timestamp) {
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
    let ft = opts.footer || "";
    if (opts.timestamp) ft += (ft ? " • " : "") + `<t:${Math.floor(opts.timestamp.getTime() / 1000)}:R>`;
    if (ft) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ${ft}`));
  }
  return container;
}
