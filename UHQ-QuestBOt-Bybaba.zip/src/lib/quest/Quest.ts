
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder, SectionBuilder, ThumbnailBuilder, MessageFlags } from "discord.js";
import { SadieTheme } from "../../config/theme.js";
import emojis from "../../config/emojis.js";
import questsConfig from "../../config/questsConfig.js";
import { client } from "../../index.js";
import { QuestApi, QuestAssets } from "../../interface/quest.js";
import { isVideoFile } from "../../utils/quest/imageUtils.js";
import { getUrlFromDatabase, refreshExpiredImage } from "../../utils/quest/questsUtils.js";
import { decodeTimestampFromUrl } from "../../utils/quest/tokenUtils.js";
import { User } from "./User.js";
import { I18nInstance } from "../../core/i18n.js";
import { questRepo, questsCache } from "../../core/cache.js";
import { formatDiscordTimestamp } from "../../utils/tools.js";
import moment from "moment-timezone";
export enum RewardType {
    DiscordDecorations = 3,
    DiscordOrb = 4,
    Nitro = 5,
}
export class Quest {
    token: string;
    id: string
    user: User

    data: QuestApi
    constructor(quest: QuestApi, user: User) {
        this.id = quest.id;
        this.data = quest;
        this.user = user;
    }
    get i18n(): I18nInstance {
        return this.user.i18n;
    }
    get taskV1() {
        return this?.data?.config?.task_config?.tasks
    }
    get tasksV2() {
        return this?.data?.config?.task_config_v2?.tasks
    }
    get tasks() {
        return this.tasksV2 ?? this.taskV1
    }
    get application() {
        return this?.data?.config?.application
    }
    get assets() {
        return Object.entries(this?.data?.config?.assets).reduce((acc, [key, value]) => {
            acc[key] = this.cdn(value);
            return acc;
        }, {}) as QuestAssets
    }
    get startsAt() {
        return this?.data?.config?.starts_at
    }
    getTaskType(taskId: string) {
        const durationQuests = questsConfig.durationQuests;
        return durationQuests.includes(taskId) ? "duration" : "count"
    }
    get progress() {
        const progress = this?.data?.user_status?.progress;
        return Object.keys(this.tasks).map(key => {
            const task = this.tasks[key];
            const taskProgress = progress?.[key]
            const target = task.target;
            const current = taskProgress?.value ?? 0;
            const percent = Math.min(100, Math.floor((current / target) * 100));
            const emoji = client.getEmoji(key, true);
            const type = this.getTaskType(key);
            const completed = taskProgress?.completed_at && true || percent >= 100;
            const enrolled = this?.data?.user_status?.enrolled_at ? true : false;
            return {
                id: key,
                type: type,
                target,
                enrolled,
                current,
                percent,
                emoji,
                completed
            }
        }).sort((a, b) => b.percent - a.percent);
    }
    get rewards() {
        const rewards = this?.data?.config?.rewards_config.rewards;

        return rewards.map(reward => {

            return {

                ...reward
            }
        });

    }
    formatProgress(): string {
        const tasks = this.progress.map((task) => {
            return `-# ${task?.emoji || ""} ${task.percent}%`;
        });

        return `${tasks.join("\n").trim()}`;
    }
    formatTasks(i18n: I18nInstance = this.i18n): string {

        const capitalizeWords = (str: string) =>
            str
                .split("_")
                .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(" ");

        const tasks = this.progress.map((task) => {
            const taskKey = task.id;
            const isDuration = task.type === "duration";
            const target = isDuration ? task.target * 1000 : task.target;
            const formattedTarget = isDuration
                ? client.formatDuration(target, i18n.getLang(), ["m", "s"])
                : String(target);

            const i18nKey = `events.${taskKey}`
            let formattedName = this.i18n.t(i18nKey);
            if (formattedName == i18nKey) formattedName = capitalizeWords(taskKey);
            const taskDescription = isDuration
                ? `${i18n.t("for")} ${formattedTarget.trim()}`
                : formattedTarget;
            const emoji = task.emoji
            return `- ${formattedName} ${taskDescription} ${emoji || ""}`.trim();
        });

        return `**${tasks.join("\n")}**`;
    }

    isOrb(): boolean {
        return this.data.config.features.includes(RewardType.DiscordOrb);
    }
    isNitro(): boolean {
        return this.data.config.features.includes(RewardType.Nitro);
    }
    cdn(path: string) {
        if (!path) return null;
        const base = "https://cdn.discordapp.com";
        if (path?.startsWith("quests/")) {
            return `${base}/${path}`;
        }
        return `${base}/quests/${this.id}/${path}`;
    }
    async getRewardImage() {
        const reward = this?.rewards[0];
        const rewardId = reward?.sku_id;
        const customRewardsImage = questsConfig?.customRewardsImage?.[rewardId];
        if (customRewardsImage) {
            return customRewardsImage;
        };
        const rewardType = reward.type;
        const asset = reward.asset;
        if (!asset) return null;
        const url = this.cdn(asset);
        const fileName = `${reward.asset.split(".")[0]}-${this.id}`;
        const round = rewardType === RewardType.DiscordDecorations;
        const isVideo = isVideoFile(url);
        let finalUrl = url;
        if (isVideo) {
            const image = await getUrlFromDatabase(fileName, url, round);
            if (image) finalUrl = image;
        }
        return finalUrl;
    }
    get image() {
        const reward = this?.rewards[0];
        const rewardId = reward?.sku_id;
        const customRewardsImage = questsConfig?.customRewardsImage?.[rewardId];
        if (customRewardsImage) {
            return customRewardsImage;
        }
        const rewardType = reward.type;
        const asset = reward.asset;
        if (!asset) return null;
        const url = this.cdn(asset);
        const fileName = `${reward.asset.split(".")[0]}-${this.id}`;

        const isVideo = isVideoFile(url);
        const clientImage = client.images.get(fileName);
        let finalUrl = url;
        if (isVideo && !clientImage) {
            this.getRewardImage()
        }
        else if (isVideo && clientImage) {
            const isExpired = clientImage && decodeTimestampFromUrl(clientImage.url) < Date.now();
            if (isExpired) {
                refreshExpiredImage(clientImage);
            }
            finalUrl = clientImage.url;
        }
        return finalUrl;
    }

    async loadEmoji() {
        const currentEmoji = client.getEmoji(this.id, false);
        if (currentEmoji) return currentEmoji;
        const rewardImage = await this.getRewardImage();
        const isVideo = rewardImage && isVideoFile(rewardImage) || false;
        if (rewardImage && isVideo) return null;
        if (rewardImage && !isVideo) {

            return await client.createEmoji(this.id, rewardImage, true);
        }
    }
    get emoji() {
        const reward = this?.rewards?.[0];
        const rewardId = reward?.sku_id;
        const completed = this.isCompleted();
        if (completed) {
            return client.getEmoji("completed", false) || "✅";
        }
        if (rewardId) {
            const customId = questsConfig?.customRewardsEmoji?.[rewardId];
            if (customId) {
                const customEmoji = client.getEmoji(customId, false);
                if (customEmoji) return customEmoji;
            }
        }
        let questEmoji = client.getEmoji(this.id, false);
        if (!questEmoji) {
            this.loadEmoji();
            questEmoji = client.getEmoji(this.id, false);
        }
        return questEmoji || emojis(client)?.quest || "🎉";
    }

    get messages() {
        return this.data.config.messages;
    }
    get displayLabel() {
        return `${this?.messages?.game_title && `${this?.messages?.game_title}: ` || ""}${this?.messages?.quest_name}`;
    }
    get rewardLabel() {
        const reward = this?.rewards[0];
        const type = reward?.type;
        let i18nKey = `rewardTypes.${type}`
        let customRewardsLabel = this.i18n.t(`rewardTypes.${type}`);
        if (i18nKey == customRewardsLabel) customRewardsLabel = null;

        let text = reward.messages.name;
        if (customRewardsLabel) text += ` (${customRewardsLabel})`
        return text;
    }
    isCompleted(): boolean {
        return this?.data?.user_status?.completed_at ? true : false;
    }
    isSupported(): boolean {
        return this.progress.some(e => client.questsSupported.includes(e.id))
    }
    get solveMethod() {
        return this?.progress?.find(e => client.questsSupported.includes(e.id));
    }
    async getDb() {
        let quest = await questsCache.get(this.id);
        if (quest) return quest;

        if (!quest) {
            quest = await questRepo.findOne({ where: { questId: this.id } });
            if (!quest) {
                quest = questRepo.create({
                    questId: this.id,
                    messageSent: false,
                    timeSolved: 0,
                });
                await questRepo.save(quest);
            }
            questsCache.set(this.id, quest);
        }

        return quest
    }

    async incrementQuestSolved(): Promise<boolean> {
        let quest = await questsCache.get(this.id);

        if (!quest) {
            quest = await questRepo.findOne({ where: { questId: this.id } });
            if (!quest) {
                quest = questRepo.create({
                    questId: this.id,
                    messageSent: false,
                    timeSolved: 0,
                });
            }
        }

        quest.timeSolved = (quest.timeSolved || 0) + 1;

        await questRepo.save(quest);
        questsCache.set(this.id, quest);

        return true;
    }

    async getSolvedCount(): Promise<number> {
        let quest = await questsCache.get(this.id);

        if (!quest) {
            quest = await questRepo.findOne({ where: { questId: this.id } });
            if (quest) await questsCache.set(this.id, quest);
        }

        return quest?.timeSolved ?? 0;
    }
    getRewardsDisplay(i18n: I18nInstance = this.i18n) {

        const emojiList = client.emojisList;
        let rewards: any = this.rewards.map(reward => {
            let rewardText = reward.messages.name;
            const forWord = i18n.t("for");
            const months = i18n.t("months");
            const emoji = emojiList?.[`${reward.type}`];

            if ([1, 3].includes(reward.expiration_mode)) {
                rewardText += ` ${forWord} ${moment(reward.expires_at).diff(moment(moment(this.startsAt)), "months")} ${months}`;
            };
            if (emoji) {
                rewardText += ` ${emoji || ""}`;
            };
            return rewardText
        });
        return rewards = `- **${rewards.join("\n- ").trim()}**`;
    }
    async notification_message(i18n: I18nInstance = this.i18n) {
        await Promise.all([
            this.getRewardImage(),
        ])
        const quest = this;
        const role = questsConfig?.notification?.role;
        const isValidRole = client.isSnowflakeId(role);
        let rewards: any = this.getRewardsDisplay(i18n);
        const tasks = quest.formatTasks(i18n);
        const expiresAt = quest?.data?.config?.expires_at;
        const image = quest.image;

        const accent = parseInt((quest.data.config.colors.primary || "#06c2fb").replace("#",""),16) || 0x06c2fb;
        const container = new ContainerBuilder().setAccentColor(accent);
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${i18n.t("message.newQuest")}`));
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
        if (image) {
            container.addSectionComponents(new SectionBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**${i18n.t("message.gameName")}:** ${quest.data.config.messages.game_title}`),
                    new TextDisplayBuilder().setContent(`**${i18n.t("message.questName")}:** ${quest.data.config.messages.quest_name}`)
                )
                .setThumbnailAccessory(new ThumbnailBuilder().setDescription("thumb").setURL(image)));
        } else {
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**${i18n.t("message.gameName")}:** ${quest.data.config.messages.game_title}`),
                new TextDisplayBuilder().setContent(`**${i18n.t("message.questName")}:** ${quest.data.config.messages.quest_name}`)
            );
        }
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**${i18n.t("message.startsAT")}:** ${formatDiscordTimestamp(new Date(quest.startsAt).getTime(), "Date")} (${formatDiscordTimestamp(new Date(quest.startsAt).getTime(), "R")})`),
            new TextDisplayBuilder().setContent(`**${i18n.t("message.expiresAt")}:** ${expiresAt ? `${formatDiscordTimestamp(new Date(expiresAt).getTime(), "Date")} (${formatDiscordTimestamp(new Date(expiresAt).getTime(), "R")})` : i18n.t("message.noExpires")}`),
            new TextDisplayBuilder().setContent(`## ${i18n.t("message.rewards")}: \n${rewards}`),
            new TextDisplayBuilder().setContent(`## ${i18n.t("message.tasks")}:\n${tasks}`)
        );
        if (quest.assets.hero) {
            container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setDescription("hero").setURL(quest.assets.hero)));
        }
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ${SadieTheme.emojis.max} ${quest.data.config.application.name} • ${SadieTheme.footer.text} • <t:${Math.floor(moment(quest.startsAt).toDate().getTime()/1000)}:R> ${SadieTheme.emojis.max}`));
        let content = undefined;
        if (isValidRole) {
            content = `||<@&${role}>||`
        };
        const supportButton = new ButtonBuilder().setEmoji("🤖").setStyle(ButtonStyle.Secondary).setDisabled(!this.isSupported).setCustomId(`supportbot`);
        const questLink = new ButtonBuilder().setStyle(ButtonStyle.Link).setEmoji("🔗").setLabel(i18n.t("badge.ViewQuest")).setURL(`https://discord.com/quests/${this.id}`);
        const buttonsRow = new ActionRowBuilder<any>().addComponents(questLink, supportButton);
        container.addActionRowComponents(buttonsRow as any);
        return { components: [container], flags: MessageFlags.IsComponentsV2, content };
    }

    get button(): ButtonBuilder {

        const i18n = this.i18n;
        const supported = this.isSupported();
        const completed = this.progress.some(e => e.completed);
        const enrolled = this.progress.some(e => e.enrolled);
        const started = this.user.started;
        const stoped = this.user.stoped;

        let customId: string;
        let label: string;
        let emoji: string;
        let style: ButtonStyle;
        let disabled = !enrolled || !supported;

        if (completed) {
            customId = "completed";
            label = i18n.t("buttons.completed")
            emoji = client.getEmoji("completed", false) || "✅";
            style = ButtonStyle.Secondary;
            disabled = true;
        }
        else if (!supported) {
            customId = "notsupported";
            label = i18n.t("buttons.notsupported")
            emoji = client.getEmoji("notsupported", false) || "❌";
            style = ButtonStyle.Secondary;
            disabled = true;
        }
        else if (enrolled) {
            if (started) {
                customId = "stop";
                label = i18n.t("buttons.stop")
                emoji = client.getEmoji("stop", false) || "⏹️";
                style = ButtonStyle.Secondary;
                disabled = stoped;
            } else {
                customId = "start";
                label = i18n.t("buttons.start")
                emoji = client.getEmoji("start", false) || "▶️";
                style = ButtonStyle.Secondary;
            }
        } else if (!enrolled && supported) {
            customId = "enroll";
            label = i18n.t("buttons.enroll")
            emoji = client.getEmoji("enroll", false) || "➕";
            style = ButtonStyle.Secondary;
            disabled = false
        }

        return new ButtonBuilder()
            .setCustomId(customId)
            .setLabel(label)
            .setEmoji(emoji)
            .setStyle(style)
            .setDisabled(disabled);
    }
    async enroll() {
        const url = `https://discord.com/api/v9/quests/${this.id}/enroll`;
        const data = { location: 11, is_targeted: false, metadata_raw: null }
        const response = await this.user.api.post(url, data).then(res => res.data).catch((err) => err?.response?.data);
        if (response?.enrolled_at) {
            this.data.user_status = response;
            return true;
        }
        else {
            return false;
        }

    }
    destroy() {
        

    }

}