import "express-session";

declare module "express-session" {
  interface SessionData {
    user?: {
      id: string;
      username: string;
      global_name: string;
      avatar: string | null;
      discriminator: string;
    };
    accessToken?: string;
  }
}
