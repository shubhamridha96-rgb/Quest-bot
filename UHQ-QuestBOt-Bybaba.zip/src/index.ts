import { Logger } from "./core/logger.js";
import { initializeDatabase } from "./providers/appDataSource.js";
import botClient from "./providers/client.js";

export let AppDataSource: any;
(global as any).AppDataSource = null;
(async () => {
  try {
    const ds = await initializeDatabase();
    AppDataSource = ds;
    (global as any).AppDataSource = ds;
    Logger.info("DB ready");
    const { hydrateStores }     = await import("./core/stores.js");
    const { hydrateTokenStore } = await import("./core/tokenStore.js");
    await Promise.all([hydrateStores(), hydrateTokenStore()]);
    Logger.info("In-memory stores hydrated from DB");
  } catch (e: any) {
    Logger.warn("DB init failed — running with in-memory stores only. " + e?.message);
  }
  try {
    const { startApiServer } = await import("./api/server.js");
    startApiServer();
  } catch (e: any) {
    Logger.warn("API server failed to start: " + e?.message);
  }
})();

export const client = botClient;
