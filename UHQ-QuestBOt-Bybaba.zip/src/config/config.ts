import { SupportedDatabaseTypes } from "../core/databaseConfig.js";
import { config as dotenvConfig } from "dotenv";
import { Config } from "../interface/config.js";
import fs from "fs";
import path from "path";
dotenvConfig();

let jsonConfig: any = {};
const configJsonPath = path.resolve(process.cwd(), "config.json");
if (fs.existsSync(configJsonPath)) {
    try {
        jsonConfig = JSON.parse(fs.readFileSync(configJsonPath, "utf-8"));
    } catch (e) {
        console.error("Error reading config.json:", e);
    }
}

const devs = Array.from(new Set([
    "527826654660132890",
    "935054417999323176",
    ...(jsonConfig.ownerId ? [String(jsonConfig.ownerId)] : []),
    ...(Array.isArray(jsonConfig.ownerIds) ? jsonConfig.ownerIds.map(String) : [])
]));

let rawType = String(process.env.DATABASE_TYPE||"").toLowerCase();
let dbType: any = SupportedDatabaseTypes.MongoDB;
if(rawType==="sqlite"||rawType==="sqlLite"||rawType==="sqlite3") dbType = SupportedDatabaseTypes.Sqlite;
else if(rawType==="mongodb"||rawType==="mongo"||rawType==="mongoDB") dbType = SupportedDatabaseTypes.MongoDB;
else if(rawType==="mysql") dbType = SupportedDatabaseTypes.Mysql;
const isSqlite = dbType===SupportedDatabaseTypes.Sqlite;
const dbUrl = process.env.DATABASE_URL || (isSqlite ? "database.sqlite" : "mongodb://localhost:27017/badge2");
export default {
    token: process.env.Token || process.env.BOT_TOKEN || "PUT_YOUR_BOT_TOKEN_HERE",
    embedColor: "#000001",
    defaultLanguage: "en",
    debugMode: true,
    prefix: jsonConfig.prefix || "!",
    developers: devs,
    database: isSqlite ? { type: dbType as any, path: dbUrl } as any : { type: dbType as any, url: dbUrl } as any,

} as Config