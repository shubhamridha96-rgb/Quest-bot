
export const SadieTheme = {
  colors: {
    
    primary:       0x000001,
    primaryHex:    "#000001",

    
    error:         0x1A1A1A,

    
    success:       0x2B2D31,

    
    dark:          0x000001,

    
    upsideDown:    0x6D023A,

    
    hawkins:       0x1A1A2E,

    
    amber:         0xF4A400,
  },
  banners: {
    
    fallback: "https://k.top4top.io/p_3343xcnvn1.png",

    
    hero:     "https://upload.wikimedia.org/wikipedia/commons/c/c3/Sadie_Sink_by_Gage_Skidmore.jpg",

    
    cinematic:"https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=1200&auto=format&fit=crop",
  },

  gallery: [
    "https://upload.wikimedia.org/wikipedia/commons/c/c3/Sadie_Sink_by_Gage_Skidmore.jpg",
    "https://upload.wikimedia.org/wikipedia/commons/9/9e/Sadie_Sink_%2847041144894%29.jpg",
    "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=600&auto=format&fit=crop",
  ],
  emojis: {
    max:        "<a:emoji_5:1571194469263483051>",
    upsideDown: "🌑",
    hawkins:    "🏫",
    star:       "⭐",
    heart:      "<a:emoji_5:1571194469263483051>",
    fire:       "<a:emoji_5:1571194469263483051>",
    tick:       "<a:emoji_7:1571194594400407732>",
  },
  footer: {
    text: "Max Mayfield • Sadie Sink • Stranger Things",
    icon: "https://upload.wikimedia.org/wikipedia/commons/c/c3/Sadie_Sink_by_Gage_Skidmore.jpg",
  },
  branding: {
    titlePrefix: "<a:emoji_5:1571194469263483051>",
    separator:   "━━━  Stranger Things  ━━━",
    tagline:     "Questy — Sadie Sink Edition",
  },
} as const;

export type SadieThemeType = typeof SadieTheme;
