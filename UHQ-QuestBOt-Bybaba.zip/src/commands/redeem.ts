import { messageCommand, MessageCommandContext, MessageCommandFlagKeys } from "../lib/handler/messageCommand.js";
import { keys, premium } from "../core/stores.js";
import {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  SectionBuilder,
  ThumbnailBuilder,
  MessageFlags,
} from "discord.js";
import { SadieTheme } from "../config/theme.js";

export default class RedeemMessageCommand extends messageCommand {
  public name: string = "redeem";
  public description: string = "Redeem a premium subscription key.";
  public aliases?: string[] = ["claimkey", "usekey"];
  public usage: string = "{prefix}{command} <key>";
  public examples?: string[] = ["!redeem QUESTY-BABAOP-365VIP"];
  public cooldown: number | string = "2s";
  public flags: MessageCommandFlagKeys[] = [];
  public permissions = [];
  public bot_permissions = [];

  public async execute(options: MessageCommandContext): Promise<void> {
    const { message, args } = options;
    const k = args[0]?.trim();

    const makeCard = (title: string, desc: string, color: number) => {
      const c = new ContainerBuilder().setAccentColor(color);
      c.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(title),
        new TextDisplayBuilder().setContent(desc)
      );
      c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
      c.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text}`)
      );
      return { components: [c], flags: MessageFlags.IsComponentsV2 };
    };

    if (!k) {
      await message.reply(makeCard(
        "# ⚠️  Invalid Usage",
        "Kripya apni key specify karein:\n`!redeem <your_key>`\n\n*Example:* `!redeem QUESTY-BABAOP-365VIP`",
        SadieTheme.colors.amber
      ) as any).catch(() => null);
      return;
    }

    const v = keys.get(k);
    if (!v) {
      await message.reply(makeCard(
        "# ❌  Invalid Key",
        "Yeh key database me nahi mili ya galat enter ki gayi hai.",
        SadieTheme.colors.error
      ) as any).catch(() => null);
      return;
    }

    if (v.usedBy) {
      await message.reply(makeCard(
        "# ❌  Key Already Used",
        `Yeh key pehle hi <@${v.usedBy}> dwara redeem ho chuki hai.`,
        SadieTheme.colors.error
      ) as any).catch(() => null);
      return;
    }

    v.usedBy = message.author.id;
    premium.set(message.author.id, {
      since: Date.now(),
      until: Date.now() + v.days * 24 * 3600 * 1000
    });

    const successContainer = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);
    const headerSection = new SectionBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# 🎉  Subscription Activated!`),
        new TextDisplayBuilder().setContent(
          `**User:** <@${message.author.id}>\n` +
          `**Tier:** Premium VIP ${SadieTheme.emojis.star}\n` +
          `**Duration:** **${v.days >= 9999 ? "Lifetime Access" : `${v.days} Days`}**\n` +
          `**Status:** <a:emoji_7:1571194594400407732> Active`
        )
      )
      .setThumbnailAccessory(
        new ThumbnailBuilder()
          .setDescription("Premium Star")
          .setURL("https://k.top4top.io/p_3343xcnvn1.png")
      );

    successContainer.addSectionComponents(headerSection);
    successContainer.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
    successContainer.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `Aapke account par multi-account slots aur automated quest processing unlock ho chuka hai.\nAb aap \`!link\` se multiple tokens bind kar sakte hain!`
      )
    );
    successContainer.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
    successContainer.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text} ${SadieTheme.emojis.max}`)
    );

    await message.reply({ components: [successContainer], flags: MessageFlags.IsComponentsV2 } as any).catch(() => null);
  }
}
