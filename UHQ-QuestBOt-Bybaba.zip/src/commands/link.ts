import { messageCommand, MessageCommandContext, MessageCommandFlagKeys } from "../lib/handler/messageCommand.js";
import { addProfile, getProfiles, mask, validateProfile, MAX_PROFILES } from "../core/tokenStore.js";
import {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  SectionBuilder,
  ThumbnailBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} from "discord.js";
import { SadieTheme } from "../config/theme.js";

const MAX_SLOTS = 3;
const IDLE_MS = 120_000;

export default class LinkMessageCommand extends messageCommand {
  public name: string = "link";
  public description: string = "Connect your Discord user token or view token profile dashboard.";
  public aliases?: string[] = ["connect-token", "addtoken", "profiles"];
  public usage: string = "{prefix}{command} [token]";
  public examples?: string[] = ["{prefix}link", "{prefix}link mfa.xxxxxxx"];
  public cooldown: number | string = "2s";
  public flags: MessageCommandFlagKeys[] = [];
  public permissions = [];
  public bot_permissions = [];

  public async execute(options: MessageCommandContext): Promise<void> {
    const { message, args } = options;
    if (args.length > 0) {
      if (message.guild && message.guild.members.me?.permissions.has("ManageMessages")) {
        await message.delete().catch(() => null);
      }
      const rawToken = args.join(" ").replace(/["']/g, "").trim();
      const res = addProfile(message.author.id, rawToken);

      if (!res.ok) {
        await message.reply({
          content: `❌ **Failed to link token**: ${res.error}`
        }).catch(() => null);
        return;
      }

      await message.reply({
        content: `<a:emoji_7:1571194594400407732> **Successfully linked token** for account <@${res.profile?.id}> (\`${res.profile?.id}\`)!`
      }).catch(() => null);
      return;
    }
    const profiles = getProfiles(message.author.id);

    const buildCard = (): any => {
      const container = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);

      const headerText = [
        "# 💳  User Token Profiles",
        `**User:** <@${message.author.id}>`,
        `**Subscription:** Normal ${SadieTheme.emojis.star}`,
        `**Connected Slots:** ${profiles.length} / ${MAX_SLOTS}`,
      ].join("\n");

      const headerSection = new SectionBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(headerText))
        .setThumbnailAccessory(
          new ThumbnailBuilder()
            .setDescription("User avatar")
            .setURL(
              message.author.displayAvatarURL?.({ size: 128, extension: "png" }) ??
              SadieTheme.banners.fallback
            )
        );

      container.addSectionComponents(headerSection);

      container.addSeparatorComponents(
        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
      );

      if (profiles.length === 0) {
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `> You currently have **0** accounts connected.\n>\n> Click **Add Token** below to connect your first Discord Token.`
          )
        );
      } else {
        const lines = profiles.map((p, i) => {
          const status = p.valid === false ? "❌ Invalid" : `<a:emoji_7:1571194594400407732> ${p.username ?? "Active"}`;
          return `> **#${i + 1}** <@${p.id}> \`${mask(p.token)}\` — ${status}`;
        });

        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(lines.join("\n")));
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`-# ${profiles.length}/${MAX_SLOTS} slots used`)
        );
      }

      container.addSeparatorComponents(
        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false)
      );

      const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("profiles_add")
          .setLabel("Add Token")
          .setStyle(ButtonStyle.Success)
          .setEmoji("➕"),
        new ButtonBuilder()
          .setCustomId("profiles_refresh")
          .setLabel("Refresh")
          .setStyle(ButtonStyle.Secondary)
          .setEmoji("🔄")
      );

      container.addActionRowComponents(row1 as any);

      if (profiles.length > 0) {
        const menu = new StringSelectMenuBuilder()
          .setCustomId("profiles_select")
          .setPlaceholder("Select a profile to manage…")
          .setMinValues(1)
          .setMaxValues(1);

        profiles.forEach(p =>
          menu.addOptions({
            label: (p.username ?? p.id).slice(0, 25),
            value: p.id,
            description: mask(p.token).slice(0, 30),
            emoji: p.valid === false ? "❌" : "✅",
          })
        );

        container.addActionRowComponents(new ActionRowBuilder().addComponents(menu as any) as any);
      }

      container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text} ${SadieTheme.emojis.max}`
        )
      );

      return { components: [container], flags: MessageFlags.IsComponentsV2 };
    };

    const sentMsg = await message.reply(buildCard() as any).catch(err => {
      console.error("Failed to send profiles card:", err);
      return null;
    });

    if (!sentMsg) return;

    const col = (sentMsg as any).createMessageComponentCollector({
      filter: (i: any) => i.user.id === message.author.id,
      time: IDLE_MS,
    });

    col.on("collect", async (i: any) => {
      if (i.customId === "profiles_add") {
        const modal = new ModalBuilder()
          .setCustomId("profiles_modal_add")
          .setTitle("Connect Token");

        modal.addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder()
              .setCustomId("token")
              .setLabel("Discord Token")
              .setStyle(TextInputStyle.Paragraph)
              .setRequired(true)
          ) as any
        );

        await i.showModal(modal);

        try {
          const m = await i.awaitModalSubmit({
            time: 60_000,
            filter: (x: any) => x.user.id === message.author.id,
          });

          const raw = m.fields.getTextInputValue("token");
          const result = addProfile(message.author.id, raw);

          await m.reply({
            content: result.ok ? `<a:emoji_7:1571194594400407732> Connected <@${result.profile!.id}>` : `❌ ${result.error}`,
            ephemeral: true,
          } as any);

          if (result.ok) {
            const fresh = getProfiles(message.author.id);
            profiles.splice(0, profiles.length, ...fresh);
            await sentMsg.edit(buildCard() as any).catch(() => null);
          }
        } catch {}
        return;
      }

      if (i.customId === "profiles_refresh") {
        for (const p of profiles) await validateProfile(p);
        await i.update(buildCard() as any).catch(() => null);
        return;
      }

      if (i.customId === "profiles_select") {
        const id = i.values[0];
        const p = profiles.find(x => x.id === id);
        if (!p) {
          await i.update(buildCard() as any).catch(() => null);
          return;
        }

        const manageContainer = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);
        manageContainer.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `# ⚙️  Manage Profile: <@${p.id}>\n**ID:** \`${p.id}\`\n**Token:** \`${mask(p.token)}\`\n**Status:** ${p.valid === false ? "❌ Invalid" : "<a:emoji_7:1571194594400407732> Valid"}`
          )
        );

        const manageRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`profiles_rm_${p.id}`)
            .setLabel("Remove Profile")
            .setStyle(ButtonStyle.Danger)
            .setEmoji("🗑️"),
          new ButtonBuilder()
            .setCustomId("profiles_back")
            .setLabel("Back")
            .setStyle(ButtonStyle.Secondary)
            .setEmoji("⬅️")
        );
        manageContainer.addActionRowComponents(manageRow as any);

        await i.update({ components: [manageContainer], flags: MessageFlags.IsComponentsV2 } as any);
        return;
      }

      if (i.customId === "profiles_back") {
        await i.update(buildCard() as any).catch(() => null);
        return;
      }

      if (i.customId.startsWith("profiles_rm_")) {
        const id = i.customId.replace("profiles_rm_", "");
        const { removeProfile } = await import("../core/tokenStore.js");
        removeProfile(message.author.id, id);
        const fresh = getProfiles(message.author.id);
        profiles.splice(0, profiles.length, ...fresh);
        await i.update(buildCard() as any).catch(() => null);
      }
    });
  }
}
