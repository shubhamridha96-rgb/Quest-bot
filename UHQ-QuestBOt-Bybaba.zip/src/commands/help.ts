
import {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    SectionBuilder,
    ThumbnailBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
} from "discord.js";

import {
    messageCommand,
    MessageCommandContext,
    MessageCommandFlagKeys,
} from "../lib/handler/messageCommand.js";

type HelpPage =
    | "home"
    | "accounts"
    | "quests"
    | "premium"
    | "admin"
    | "tools";

type HelpCommand = {
    name: string;
    description: string;
};

export default class HelpMessageCommand extends messageCommand {
    public name = "help";
    public description = "Display Questy's command center";
    public aliases?: string[] = ["commands", "h", "menu"];
    public usage = "{prefix}{command}";
    public examples?: string[] = ["!help"];
    public cooldown: number | string = "2s";
    public flags: MessageCommandFlagKeys[] = [];
    public permissions = [];
    public bot_permissions = [];

    private readonly accent = 0x9370DB;

    private readonly categories: Record<
        Exclude<HelpPage, "home">,
        HelpCommand[]
    > = {
        accounts: [
            { name: "link", description: "Link an account." },
            { name: "unlink", description: "Unlink an account." },
            { name: "connect-token", description: "Connect a token." },
            { name: "disconnect-token", description: "Disconnect a token." },
            { name: "profiles", description: "View account profiles." },
            { name: "tokencheck", description: "Check token status." },
            { name: "tokens", description: "View connected tokens." },
        ],

        quests: [
            { name: "status", description: "View quest progress and status." },
            { name: "questlist", description: "View available quests." },
            { name: "questall", description: "View all quests." },
            { name: "complete-quest", description: "Complete a quest." },
            { name: "complete-all-quests", description: "Complete all available quests." },
            { name: "complete-quests", description: "Manage quest completion." },
            { name: "autouquest", description: "Automatic quest management." },
        ],

        premium: [
            { name: "premium-add", description: "Add premium access." },
            { name: "premium-info", description: "View premium information." },
            { name: "premium-list", description: "List premium users." },
            { name: "premium-remove", description: "Remove premium access." },
            { name: "redeem-panel", description: "Open the redemption panel." },
            { name: "redeem", description: "Redeem a premium key." },
            { name: "generate-keys", description: "Generate premium keys." },
            { name: "key-delete", description: "Delete a premium key." },
            { name: "key-status", description: "Check a key's status." },
            { name: "keys-list", description: "List generated keys." },
        ],

        admin: [
            { name: "blacklist-add", description: "Add a user to the blacklist." },
            { name: "blacklist-list", description: "View the blacklist." },
            { name: "blacklist-remove", description: "Remove a user from the blacklist." },
            { name: "setPrefix", description: "Change the server prefix." },
            { name: "setLang", description: "Change the bot language." },
            { name: "badge", description: "Manage badges." },
            { name: "sendMessage", description: "Send a configured message." },
            { name: "usage", description: "View usage information." },
        ],

        tools: [
            { name: "help", description: "Display this help menu." },
            { name: "ping", description: "Check bot latency." },
            { name: "dashboard", description: "Access the dashboard." },
            { name: "hypesquad", description: "View HypeSquad information." },
            { name: "nitro", description: "Nitro utilities." },
            { name: "boost", description: "Boost utilities." },
            { name: "test", description: "Run a test command." },
        ],
    };

    private getPrefix(options: MessageCommandContext): string {
        return options.guildConfig?.prefix || "!";
    }

    private getPageText(
        page: HelpPage,
        prefix: string
    ): string {
        if (page === "home") {
            const categories = [
                ["accounts", "ACCOUNT MANAGEMENT"],
                ["quests", "QUEST CENTER"],
                ["premium", "PREMIUM & KEYS"],
                ["admin", "ADMINISTRATION"],
                ["tools", "UTILITIES"],
            ] as const;

            const total = Object.values(this.categories)
                .reduce((sum, commands) => sum + commands.length, 0);

            return [
                "## ✦ COMMAND CENTER",
                "> Everything you need, in one place.",
                "",
                ...categories.map(([key, title]) =>
                    `**${title}** · \`${this.categories[key].length} commands\``
                ),
                "",
                `**${total}** commands listed`,
                "",
                `**Your prefix:** \`${prefix}\``,
                `**Example:** \`${prefix}help\``,
                "",
                "-# Select a category below to explore.",
            ].join("\n");
        }

        const titles: Record<Exclude<HelpPage, "home">, string> = {
            accounts: "ACCOUNT MANAGEMENT",
            quests: "QUEST CENTER",
            premium: "PREMIUM & KEYS",
            admin: "ADMINISTRATION",
            tools: "UTILITIES & TOOLS",
        };

        const commands = this.categories[page];

        return [
            `## ✦ ${titles[page]}`,
            "",
            ...commands.map(command =>
                `**\`${prefix}${command.name}\`**\n-# ${command.description}`
            ),
            "",
            `-# ${commands.length} commands`,
        ].join("\n");
    }

    private buildButtons(
        selected: HelpPage,
        disabled = false
    ) {
        const categories: { id: HelpPage; label: string }[] = [
            { id: "home", label: "Home" },
            { id: "accounts", label: "Accounts" },
            { id: "quests", label: "Quests" },
            { id: "premium", label: "Premium" },
            { id: "admin", label: "Admin" },
            { id: "tools", label: "Tools" },
        ];

        const makeButton = (item: typeof categories[number]) =>
            new ButtonBuilder()
                .setCustomId(`questy_help_${item.id}`)
                .setLabel(item.label)
                .setStyle(
                    selected === item.id
                        ? ButtonStyle.Primary
                        : ButtonStyle.Secondary
                )
                .setDisabled(disabled);

        return [
            new ActionRowBuilder<ButtonBuilder>().addComponents(
                categories.slice(0, 3).map(makeButton)
            ),
            new ActionRowBuilder<ButtonBuilder>().addComponents(
                categories.slice(3, 6).map(makeButton)
            ),
        ];
    }

    private buildMenu(
        options: MessageCommandContext,
        page: HelpPage,
        disabled = false
    ) {
        const prefix = this.getPrefix(options);

        const container = new ContainerBuilder()
            .setAccentColor(this.accent);

        const header = new SectionBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    [
                        "# QUESTY",
                        "-# PREMIUM COMMAND INTERFACE",
                        "",
                        "Your command center. Simplified.",
                    ].join("\n")
                )
            );

        header.setThumbnailAccessory(
            new ThumbnailBuilder()
                .setURL(
                    "https://cdn.discordapp.com/attachments/1571225240422326363/1571467466582917200/BE_Owner.gif?ex=6afad6a0&is=6af98520&hm=ca82ad888cfd2c179cbf51b8df081d3b9b12ebe784c9f6485c6b9566ae319d69"
                )
                .setDescription("Questy")
        );

        container.addSectionComponents(header);

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                "```ansi\n\u001b[35m▰▰\u001b[34m▰▰\u001b[36m▰▰\u001b[0m\n```"
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                this.getPageText(page, prefix)
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(false)
        );

        for (const row of this.buildButtons(page, disabled)) {
            container.addActionRowComponents(row);
        }

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                [
                    "-# QUESTY  •  PREMIUM EXPERIENCE",
                    "-# Use the buttons to navigate categories.",
                ].join("\n")
            )
        );

        return container;
    }

    public async execute(
        options: MessageCommandContext
    ): Promise<void> {
        const { message } = options;

        let currentPage: HelpPage = "home";

        const reply = await message.reply({
            components: [
                this.buildMenu(options, currentPage),
            ],
            flags: MessageFlags.IsComponentsV2,
        } as any);

        const collector = reply.createMessageComponentCollector({
            time: 120_000,
            filter: interaction =>
                interaction.customId.startsWith("questy_help_"),
        });

        collector.on("collect", async interaction => {
            if (interaction.user.id !== message.author.id) {
                await interaction.reply({
                    content: "This help menu belongs to another user.",
                    ephemeral: true,
                });
                return;
            }

            const page = interaction.customId.replace(
                "questy_help_",
                ""
            ) as HelpPage;

            const validPages: HelpPage[] = [
                "home",
                "accounts",
                "quests",
                "premium",
                "admin",
                "tools",
            ];

            if (!validPages.includes(page)) {
                await interaction.deferUpdate();
                return;
            }

            currentPage = page;

            await interaction.update({
                components: [
                    this.buildMenu(options, currentPage),
                ],
            } as any);
        });

        collector.on("end", async () => {
            await reply.edit({
                components: [
                    this.buildMenu(options, currentPage, true),
                ],
            } as any).catch(() => null);
        });
    }
}
