import { messageCommand, MessageCommandContext, MessageCommandFlagKeys } from "../lib/handler/messageCommand.js";
import { getProfiles, removeProfile } from "../core/tokenStore.js";

export default class UnlinkMessageCommand extends messageCommand {
    public name: string = "unlink";
    public description: string = "Remove your connected Discord user token(s).";
    public aliases?: string[] = ["disconnect-token", "removetoken"];
    public usage: string = "{prefix}{command} [account_id]";
    public examples?: string[] = ["{prefix}unlink", "{prefix}unlink 123456789012345678"];
    public cooldown: number | string = "3s";
    public flags: MessageCommandFlagKeys[] = [];
    public permissions = [];
    public bot_permissions = [];

    public async execute(options: MessageCommandContext): Promise<void> {
        const { message, args } = options;
        const profiles = getProfiles(message.author.id);

        if (!profiles || profiles.length === 0) {
            await message.reply({
                content: `❌ You do not have any tokens currently linked.`
            }).catch(() => null);
            return;
        }

        let targetId = args[0]?.trim();

        if (!targetId) {
            if (profiles.length === 1) {
                targetId = profiles[0].id;
            } else {
                const list = profiles.map(p => `• <@${p.id}> (\`${p.id}\`)`).join("\n");
                await message.reply({
                    content: `⚠️ You have multiple tokens linked. Please specify which account to remove:\n\`!unlink <account_id>\`\n\n**Your linked accounts:**\n${list}`
                }).catch(() => null);
                return;
            }
        }

        const removed = removeProfile(message.author.id, targetId);

        if (removed) {
            await message.reply({
                content: `🗑️ **Token removed**: Successfully unlinked account <@${targetId}> (\`${targetId}\`).`
            }).catch(() => null);
        } else {
            await message.reply({
                content: `❌ Could not find account ID \`${targetId}\` in your linked tokens.`
            }).catch(() => null);
        }
    }
}
