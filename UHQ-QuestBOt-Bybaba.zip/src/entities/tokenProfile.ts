import { Entity, Column, Index } from "typeorm";
import BaseDocument from "../lib/handler/BaseDocument.js";

@Entity("token_profiles")
@Index(["ownerDiscordId", "accountDiscordId"], { unique: true })
export class TokenProfileEntity extends BaseDocument {
  /** Discord user ID of the dashboard user who added this token */
  @Column()
  ownerDiscordId: string;

  /** Discord user ID extracted from the token */
  @Column()
  accountDiscordId: string;

  /** AES-256-GCM encrypted token */
  @Column({ type: "text" })
  encryptedToken: string;

  /** Cached username — refreshed on validate */
  @Column({ nullable: true })
  username?: string;

  /** Last validation result */
  @Column({ default: true })
  valid: boolean;

  /** Unix ms when this token was added */
  @Column({ type: "bigint" })
  addedAt: number;
}
