import { Entity, Column, Index } from "typeorm";
import BaseDocument from "../lib/handler/BaseDocument.js";

@Entity("premium_users")
export class PremiumEntity extends BaseDocument {
  @Column() @Index({ unique: true })
  userId: string;
  @Column({ type: "bigint" }) since: number;
  @Column({ type: "bigint" }) until: number;
}

@Entity("key_store")
export class KeyEntity extends BaseDocument {
  @Column() @Index({ unique: true })
  key: string;
  @Column() days: number;
  @Column() createdBy: string;
  @Column({ nullable: true }) usedBy?: string;
  @Column({ type: "bigint" }) createdAt: number;
}

@Entity("blacklist_store")
export class BlacklistEntity extends BaseDocument {
  @Column() @Index({ unique: true })
  userId: string;
  @Column({ nullable: true }) reason?: string;
  @Column({ type: "bigint" }) at: number;
}

@Entity("autoquest_store")
export class AutoQuestEntity extends BaseDocument {
  @Column() @Index({ unique: true })
  userId: string;
}
