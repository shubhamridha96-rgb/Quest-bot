import { Entity, Column, Index } from "typeorm";
import BaseDocument from "../lib/handler/BaseDocument.js";

@Entity("sessions")
export class SessionEntity extends BaseDocument {
  @Column() @Index({ unique: true })
  sid: string;

  @Column({ type: "text" })
  data: string;

  @Column({ type: "bigint" })
  expiresAt: number;
}
