import { Router, Request, Response } from "express";
import { Logger } from "../core/logger.js";

const router = Router();

function discordOAuthURL(clientId: string, redirectUri: string): string {
  const params = new URLSearchParams({
    client_id:     clientId,
    redirect_uri:  redirectUri,
    response_type: "code",
    scope:         "identify",
  });
  return `https://discord.com/api/oauth2/authorize?${params}`;
}
router.get("/discord", (req: Request, res: Response) => {
  const clientId    = process.env.DISCORD_CLIENT_ID;
  const redirectUri = process.env.DISCORD_REDIRECT_URI || `http://localhost:${process.env.API_PORT || 3001}/auth/discord/callback`;
  if (!clientId) return res.status(500).json({ error: "DISCORD_CLIENT_ID not set in .env" });
  res.redirect(discordOAuthURL(clientId, redirectUri));
});
router.get("/discord/callback", async (req: Request, res: Response) => {
  const code        = String(req.query.code || "");
  const clientId    = process.env.DISCORD_CLIENT_ID    || "";
  const clientSecret= process.env.DISCORD_CLIENT_SECRET|| "";
  const redirectUri = process.env.DISCORD_REDIRECT_URI || `http://localhost:${process.env.API_PORT || 3001}/auth/discord/callback`;

  if (!code) return res.redirect((process.env.FRONTEND_URL||"") + "/?auth_error=no_code");

  try {
    const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
      method:  "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body:    new URLSearchParams({
        client_id:     clientId,
        client_secret: clientSecret,
        grant_type:    "authorization_code",
        code,
        redirect_uri:  redirectUri,
      }),
    });

    if (!tokenRes.ok) {
      const err = await tokenRes.text();
      Logger.error("Discord token exchange failed:", err);
      return res.redirect((process.env.FRONTEND_URL||"") + "/?auth_error=token_exchange");
    }

    const tokenData = await tokenRes.json() as any;
    const accessToken = tokenData.access_token;
    const userRes = await fetch("https://discord.com/api/users/@me", {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (!userRes.ok) return res.redirect((process.env.FRONTEND_URL||"") + "/?auth_error=user_fetch");

    const user = await userRes.json() as any;
    (req as any).session.user = {
      id:          user.id,
      username:    user.username,
      global_name: user.global_name || user.username,
      avatar:      user.avatar,
      discriminator: user.discriminator,
    };
    (req as any).session.accessToken = accessToken;

    Logger.info(`OAuth login: ${user.username} (${user.id})`);
    const fe = process.env.FRONTEND_URL || ""; res.redirect(fe + "/?auth=success");
  } catch (err: any) {
    Logger.error("OAuth callback error:", err);
    res.redirect((process.env.FRONTEND_URL||"") + "/?auth_error=server");
  }
});
router.get("/me", (req: Request, res: Response) => {
  const user = (req as any).session?.user;
  if (!user) return res.status(401).json({ authenticated: false });
  res.json({ authenticated: true, user });
});
router.post("/logout", (req: Request, res: Response) => {
  req.session.destroy(() => res.json({ ok: true }));
});

export { router as authRouter };
