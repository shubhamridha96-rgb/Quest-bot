import express, { Request, Response, NextFunction } from "express";
import path from "path";
import { fileURLToPath } from "url";
import session from "express-session";
import { usersCache } from "../core/cache.js";
import { ChildManager } from "../core/ChildManager.js";
import client from "../providers/client.js";
import questsConfig from "../config/questsConfig.js";
import { SadieTheme } from "../config/theme.js";
import { Logger } from "../core/logger.js";
import { User } from "../lib/quest/User.js";
import { getIdFromToken, isValidDiscordToken, cleanToken, check_token } from "../utils/quest/tokenUtils.js";
import { getProfiles, addProfile, removeProfile, validateProfile, mask, MAX_PROFILES } from "../core/tokenStore.js";
import { isPremium } from "../core/stores.js";
import { authRouter } from "./auth.js";
import { TypeORMSessionStore } from "../core/sessionStore.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!(req as any).session?.user) return res.status(401).json({ error: "Not authenticated — login at /auth/discord" });
  next();
}

export function startApiServer() {
  const app  = express();
  const port = Number(process.env.API_PORT || process.env.DASHBOARD_PORT || 3001);
  let sessionStore: any;
  try {
    sessionStore = new TypeORMSessionStore();
    Logger.info("Using TypeORM session store (persistent)");
  } catch {
    Logger.warn("TypeORM session store unavailable — using in-memory store");
    sessionStore = undefined;
  }
  app.use(session({
    secret:            process.env.SESSION_SECRET || "questy-sadie-sink-secret",
    resave:            false,
    saveUninitialized: false,
    store:             sessionStore,
    cookie: {
      secure:   process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge:   7 * 24 * 3600 * 1000,  // 7 days
    },
  }));
  app.use((req, res, next) => {
    const origin = req.headers.origin || "";
    const allowed = [
      `http://localhost:3000`,
      `http://localhost:${port}`,
      process.env.FRONTEND_URL || "",
    ].filter(Boolean);
    if (allowed.includes(origin) || !origin) {
      res.header("Access-Control-Allow-Origin",      origin || "*");
      res.header("Access-Control-Allow-Credentials", "true");
      res.header("Access-Control-Allow-Headers",     "Content-Type,Authorization");
      res.header("Access-Control-Allow-Methods",     "GET,POST,DELETE,OPTIONS");
    }
    if (req.method === "OPTIONS") return res.sendStatus(204);
    next();
  });

  app.use(express.json({ limit: "2mb" }));
  app.use(express.urlencoded({ extended: true }));
  app.use("/auth", authRouter);
  app.get("/api/health", (_, res) =>
    res.json({ ok: true, bot: !!client.user, uptime: process.uptime(), theme: SadieTheme.colors.primaryHex })
  );
  const api = express.Router();
  api.use(requireAuth);
  api.get("/status", (_, res) => {
    const solvers = [...usersCache.values()].map(u => ({
      id:        u.id,
      started:   u.started,
      stoped:    u.stoped,
      completed: u.completed,
      quest:     u.selectedQuest?.id     || null,
      questName: u.selectedQuest?.data?.config?.messages?.quest_name || null,
      progress:  u.selectedQuest?.progress || [],
      logs:      u.logs.slice(-10),
    }));
    res.json({ bot: client.user ? { tag: client.user.tag, id: client.user.id } : null, totalUsage: ChildManager.TotalUsage, maxUsage: ChildManager.maxUsage, solvers, count: solvers.length });
  });
  api.get("/tokens", (req, res) => {
    const userId   = (req as any).session.user.id;
    const profiles = getProfiles(userId).map(p => ({
      id:       p.id,
      username: p.username,
      addedAt:  p.addedAt,
      valid:    p.valid,
      masked:   mask(p.token),
      slots:    getProfiles(userId).length,
      maxSlots: MAX_PROFILES,
    }));
    const premium = isPremium(userId);
    res.json({ profiles, premium, slots: profiles.length, maxSlots: MAX_PROFILES });
  });

  api.post("/tokens", async (req, res) => {
    const userId = (req as any).session.user.id;
    const raw    = String(req.body.token || "").trim();
    if (!raw) return res.status(400).json({ error: "token required" });
    const result = addProfile(userId, raw);
    if (!result.ok) return res.status(400).json({ error: result.error });
    validateProfile(result.profile!).catch(() => null);
    res.json({ ok: true, profile: { id: result.profile!.id, masked: mask(result.profile!.token), addedAt: result.profile!.addedAt } });
  });

  api.delete("/tokens/:id", (req, res) => {
    const userId = (req as any).session.user.id;
    const ok     = removeProfile(userId, req.params.id);
    if (!ok) return res.status(404).json({ error: "profile not found" });
    res.json({ ok: true });
  });

  api.post("/tokens/:id/validate", async (req, res) => {
    const userId   = (req as any).session.user.id;
    const profiles = getProfiles(userId);
    const p        = profiles.find(x => x.id === req.params.id);
    if (!p) return res.status(404).json({ error: "not found" });
    const valid = await validateProfile(p);
    res.json({ ok: true, valid, username: p.username });
  });
  api.post("/quests/scan", async (req, res) => {
    const userId   = (req as any).session.user.id;
    const tokenId  = String(req.body.tokenId || "");
    const profiles = getProfiles(userId);

    let token: string;
    if (tokenId) {
      const p = profiles.find(x => x.id === tokenId);
      if (!p) return res.status(404).json({ error: "token profile not found" });
      token = p.token;
    } else if (profiles.length > 0) {
      token = profiles[0].token;
    } else {
      return res.status(400).json({ error: "no tokens connected — add one via /api/tokens" });
    }

    const cleaned = cleanToken(token);
    const id      = getIdFromToken(cleaned);
    if (!isValidDiscordToken(cleaned) || !id) return res.status(400).json({ error: "invalid token" });
    if (!(await check_token(cleaned))) return res.status(400).json({ error: "token check failed — may be expired" });

    const proxy = questsConfig.useProxy ? client.proxy.random() : undefined;
    const user  = new User(cleaned, proxy as any);
    try {
      await user.fetchQuests();
      const list = [...user.quests.values()].map((q: any) => ({
        id:        q.id,
        name:      q.data.config.messages.quest_name,
        game:      q.data.config.messages.game_title,
        publisher: q.data.config.messages.game_publisher,
        rewards:   q.rewards,
        tasks:     q.tasks,
        expiresAt: q.data?.config?.expires_at,
        startsAt:  q.startsAt,
        hero:      q.assets?.hero,
        image:     q.image,
        enrolled:  q.progress.some((p: any) => p.enrolled),
        completed: q.isCompleted(),
        supported: q.isSupported(),
        progress:  q.progress,
        emoji:     typeof q.emoji === "string" ? q.emoji : "🎮",
      }));
      user.destroy();
      res.json({ ok: true, quests: list, count: list.length, tokenId: id });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });
  api.get("/quests/scan-all", async (req, res) => {
    const userId   = (req as any).session.user.id;
    const profiles = getProfiles(userId);
    if (profiles.length === 0) return res.status(400).json({ error: "no tokens connected" });

    const results: any[] = [];
    for (const p of profiles) {
      try {
        const cleaned = cleanToken(p.token);
        const id      = getIdFromToken(cleaned);
        if (!isValidDiscordToken(cleaned) || !id) { results.push({ tokenId: p.id, error: "invalid" }); continue; }
        const proxy = questsConfig.useProxy ? client.proxy.random() : undefined;
        const user  = new User(cleaned, proxy as any);
        await user.fetchQuests();
        const quests = [...user.quests.values()].map((q: any) => ({
          id: q.id, name: q.data.config.messages.quest_name, game: q.data.config.messages.game_title,
          hero: q.assets?.hero, image: q.image, completed: q.isCompleted(), supported: q.isSupported(),
          enrolled: q.progress.some((pp: any) => pp.enrolled), progress: q.progress,
        }));
        user.destroy();
        results.push({ tokenId: p.id, username: p.username, quests, count: quests.length });
      } catch (e: any) {
        results.push({ tokenId: p.id, error: e.message });
      }
    }
    res.json({ ok: true, results });
  });
  api.post("/quests/start", async (req, res) => {
    const userId   = (req as any).session.user.id;
    const tokenId  = String(req.body.tokenId || "");
    const questId  = String(req.body.questId || "");
    if (!questId) return res.status(400).json({ error: "questId required" });

    const profiles = getProfiles(userId);
    const p        = tokenId ? profiles.find(x => x.id === tokenId) : profiles[0];
    if (!p) return res.status(404).json({ error: "token profile not found" });

    const cleaned = cleanToken(p.token);
    const id      = getIdFromToken(cleaned);
    if (!isValidDiscordToken(cleaned) || !id) return res.status(400).json({ error: "invalid token" });
    if (usersCache.has(id)) return res.status(409).json({ error: "already running for this token" });
    if (!(await check_token(cleaned))) return res.status(400).json({ error: "token check failed" });

    const child = ChildManager.getLowestUsageChild();
    if (!child) return res.status(500).json({ error: "no worker available" });
    if (child.currentTasks >= questsConfig.questsPerChildProcess) return res.status(429).json({ error: "global quest limit reached", total: ChildManager.TotalUsage, max: ChildManager.maxUsage });

    const proxy = questsConfig.useProxy ? client.proxy.random() : undefined;
    const user  = new User(cleaned, proxy as any);
    try {
      await user.fetchQuests();
      const quest = user.quests.get(questId) || user.quests.first();
      if (!quest) { user.destroy(); return res.status(404).json({ error: "quest not found" }); }
      if (!quest.isSupported()) { user.destroy(); return res.status(400).json({ error: "quest not supported by this bot" }); }

      if (!quest.data.user_status?.enrolled_at) {
        const enrolled = await quest.enroll();
        if (!enrolled) { user.destroy(); return res.status(400).json({ error: "enroll failed" }); }
      }

      user.setQuest(quest);
      user.setProcess(child.process);
      await user.start();
      res.json({ ok: true, solverId: id, questId: quest.id, questName: quest.data.config.messages.quest_name });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });
  api.post("/quests/stop", (req, res) => {
    const userId   = (req as any).session.user.id;
    const tokenId  = String(req.body.tokenId || req.body.solverId || "");
    const u        = usersCache.get(tokenId);
    if (!u) return res.status(404).json({ error: "no active session found" });
    u.stop(true);
    res.json({ ok: true });
  });

  api.post("/quests/stop-all", (req, res) => {
    let c = 0;
    for (const u of usersCache.values()) { u.stop(true); c++; }
    res.json({ ok: true, stopped: c });
  });
  api.get("/quests/active", (req, res) => {
    const userId   = (req as any).session.user.id;
    const profiles = getProfiles(userId);
    const tokenIds = new Set(profiles.map(p => p.id));
    const sessions = [...usersCache.values()]
      .filter(u => tokenIds.has(u.id))
      .map(u => ({
        tokenId:   u.id,
        started:   u.started,
        stoped:    u.stoped,
        completed: u.completed,
        questId:   u.selectedQuest?.id || null,
        questName: u.selectedQuest?.data?.config?.messages?.quest_name || null,
        progress:  u.selectedQuest?.progress || [],
        logs:      u.logs.slice(-20),
      }));
    res.json({ sessions });
  });
  api.get("/premium", (req, res) => {
    const userId = (req as any).session.user.id;
    const prem   = isPremium(userId);
    res.json({ premium: prem });
  });

  app.use("/api", api);
  const frontendDist = path.resolve(__dirname, "../../questy_-discord-quest-automation/dist");
  app.use(express.static(frontendDist));
  app.get("/*splat", (req, res) => {
    if (req.path.startsWith("/api/") || req.path.startsWith("/auth/")) {
      return res.status(404).json({ error: "not found" });
    }
    const indexFile = path.join(frontendDist, "index.html");
    res.sendFile(indexFile, (err) => {
      if (err) res.status(200).json({ ok: true, msg: "Bot API running. Run `npm run build:web` to build the frontend." });
    });
  });

  app.listen(port, () =>
    Logger.info(`✅ Questy API + Frontend → http://localhost:${port}  |  OAuth login → http://localhost:${port}/auth/discord`)
  );
}
