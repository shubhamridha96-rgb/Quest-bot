import moment from "moment-timezone";
import { ChildUser } from "../childProcess/childUser.js";
import { QuestConfig } from "../lib/questConfig.js";
import ms from "ms";

export default new QuestConfig({
    name: "WATCH_VIDEO",
    async run(user: ChildUser) {
        const secondsNeeded = user.target;
        let progress = user.current || 0;
        const startDate = moment().unix() - progress;

        while (!user.stoped) {
            const timestamp = moment().unix() - startDate;
            const heartbeat = await user.api
                .post(`/quests/${user.quest}/video-progress`, {
                    timestamp: timestamp,
                })
                .catch((err) => err.response);

            if (!heartbeat?.data?.user_id) {
                user.stop("Error sending heartbeat");
                break;
            }

            const response = user.extractProgress(heartbeat.data);
            progress = response.value;
            user.sendUpdate(progress, response.completed === true);

            if (progress >= secondsNeeded || response?.completed === true) {
                user.stop();
                user.completed = true;
                break;
            }

            const jitter = 5 + (Math.random() * 2);
            await user.delay(ms(`${jitter}s`));
        }
    },
});