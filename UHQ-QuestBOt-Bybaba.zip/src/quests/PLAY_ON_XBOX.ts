import { ChildUser } from "../childProcess/childUser.js";
import questsConfig from "../config/questsConfig.js";
import { QuestConfig } from "../lib/questConfig.js";
import ms from "ms";

export default new QuestConfig({
    name: "PLAY_ON_XBOX",
    requireLogin: false,
    requireVoiceChannel: false,
    async run(user: ChildUser) {
        const secondsNeeded = user.target;
        let progress = user.current || 0;
        const voiceChannel = questsConfig?.voice?.channel || user.id;
        const streamKey = `call:${voiceChannel}:1`;
        
        while (!user.stoped) {
            let heartbeat = await user.api
                .post(`/quests/${user.quest}/heartbeat`, {
                    stream_key: streamKey,
                    terminal: false
                })
                .catch((err) => err.response);

            if (!heartbeat?.data?.user_id) {
                const altKey = `call:${user.id}:1`;
                heartbeat = await user.api
                    .post(`/quests/${user.quest}/heartbeat`, {
                        stream_key: altKey,
                        terminal: false
                    })
                    .catch((err) => err.response);

                if (!heartbeat?.data?.user_id) {
                    user.stop("Error sending heartbeat: " + (heartbeat?.data?.message || "rejected"));
                    break;
                }
            }

            const response = user.extractProgress(heartbeat.data);
            progress = response?.value ?? (progress + 30);
            const isCompleted = response?.completed === true || progress >= secondsNeeded;
            user.sendUpdate(progress, isCompleted);

            if (isCompleted) {
                await user.api.post(`/quests/${user.quest}/heartbeat`, {
                    stream_key: streamKey,
                    terminal: true
                }).catch(() => null);
                user.stop();
                user.completed = true;
                break;
            }

            const jitter = 20 + (Math.random() * 5);
            await user.delay(ms(`${jitter}s`));
        }
    },
});
