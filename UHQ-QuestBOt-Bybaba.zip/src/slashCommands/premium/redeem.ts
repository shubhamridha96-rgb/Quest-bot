import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
import { SlashCommandStringOption } from "discord.js";
import { keys, premium } from "../../core/stores.js";
export default class RedeemCommand extends SlashCommand {
  public name="redeem";
  public description="Redeem a premium subscription key to claim premium perks & roles";
  public options=[new SlashCommandStringOption().setName("key").setDescription("Premium key").setRequired(true)];
  public async execute({interaction}:any){
    const k=interaction.options.getString("key",true);
    const v=keys.get(k);
    if(!v) return interaction.reply(simplePayload("Invalid key", "DarkRed", true) as any);
    if(v.usedBy) return interaction.reply(simplePayload("Key already used", "DarkRed", true) as any);
    v.usedBy=interaction.user.id;
    premium.set(interaction.user.id,{since:Date.now(), until:Date.now()+v.days*24*3600*1000});
    await (interaction.deferred || interaction.replied ? interaction.editReply.bind(interaction) : interaction.reply.bind(interaction))(simplePayload("Redeemed! Premium for "+v.days+" days") as any);
  }
}
