import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
import { SlashCommandUserOption } from "discord.js";
import { premium } from "../../core/stores.js";
export default class PremiumInfoCommand extends SlashCommand {
  public name="premium-info";
  public description="Check premium status of yourself or another user";
  public options=[new SlashCommandUserOption().setName("user").setDescription("User").setRequired(false)];
  public async execute({interaction}:any){
    const u=interaction.options.getUser("user")||interaction.user;
    const p=premium.get(u.id);
    const msg=p? "Premium until <t:"+Math.floor(p.until/1000)+":R>" : "No premium";
    await (interaction.deferred || interaction.replied ? interaction.editReply.bind(interaction) : interaction.reply.bind(interaction))(simplePayload(u.tag+": "+msg) as any);
  }
}
