import {
  ChatInputCommandInteraction,
  GuildMember,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  SectionBuilder,
  ThumbnailBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  MessageFlags,
} from "discord.js";
import { SlashCommand, slashCommandFlags } from "../../lib/handler/slashCommand.js";
import { CustomClient } from "../../core/customClient.js";
import { permissionList } from "../../lib/handler/messageCommand.js";
import { I18nInstance } from "../../core/i18n.js";
import { User } from "../../lib/quest/User.js";
import questsConfig from "../../config/questsConfig.js";
import { getProfiles, mask, TokenProfile } from "../../core/tokenStore.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
import { usersCache } from "../../core/cache.js";
import { ChildManager } from "../../core/ChildManager.js";
import { Logger } from "../../core/logger.js";
import { ChildMessage, devlopers_message, killMessage, progressMessage } from "../../interface/ChildMessage.js";
import { delay, disableComponents } from "../../utils/tools.js";
import { SadieTheme } from "../../config/theme.js";
export function buildTokenPickerCard(profiles: TokenProfile[]): ContainerBuilder {
  const c = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);

  c.addTextDisplayComponents(
    new TextDisplayBuilder().setContent("# 🔥 Select a Token"),
    new TextDisplayBuilder().setContent(
      `You have **${profiles.length}** token${profiles.length > 1 ? "s" : ""} connected. Pick the account to run the quest on.`
    )
  );

  c.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
  );

  profiles.forEach((p, i) => {
    c.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**#${i + 1}** <@${p.id}> \`${mask(p.token)}\` ${p.valid === false ? "❌" : "✅"}`
      )
    );
  });

  c.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false)
  );

  const menu = new StringSelectMenuBuilder()
    .setCustomId("quest_token_pick")
    .setPlaceholder("Choose your account…")
    .setMinValues(1)
    .setMaxValues(1);

  profiles.forEach((p, i) =>
    menu.addOptions({
      label:       `#${i + 1} ${(p.username ?? p.id).slice(0, 22)}`,
      value:       p.id,
      description: mask(p.token),
      emoji:       p.valid === false ? "❌" : "✅",
    })
  );

  c.addActionRowComponents(new ActionRowBuilder().addComponents(menu as any) as any);
  c.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      `-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text} ${SadieTheme.emojis.max}`
    )
  );

  return c;
}
export default class BadgeCommand extends SlashCommand {
  public name        = "quest";
  public description = "Start a Discord quest using one of your saved tokens";
  public options     = [];

  public cooldown: number | string      = "1m";
  public permissions: permissionList[]  = [];
  public bot_permissions: permissionList[] = [];
  public flags: slashCommandFlags[]     = ["noReply"];
  private safeEdit(msg: any, payload: any) {
    return msg.edit(payload).catch(() => null);
  }

  private async logAndUpdate(user: User, msg: any, log: string) {
    user.logs.push(log);
    await this.safeEdit(msg, { ...user.genreate_message() });
  }

  private async getMember(id: string, client: CustomClient): Promise<GuildMember | null> {
    const guild =
      this.client.guilds.cache.get(questsConfig.serverId) ??
      (await this.client.guilds.fetch(questsConfig.serverId).catch(() => null));
    return guild?.members?.cache.get(id) ?? (await guild?.members.fetch(id).catch(() => null)) ?? null;
  }

  private async tryFetchQuests(user: User, msg: any, i18n: I18nInstance): Promise<boolean> {
    try {
      const quests = await user.fetchQuests();
      if (!quests) { await this.safeEdit(msg, simplePayload(i18n.t("badge.errorFetch"))); return false; }
      return true;
    } catch (err) {
      Logger.error("Failed to fetch quests:", err);
      await this.safeEdit(msg, simplePayload(i18n.t("badge.errorFetch")));
      return false;
    }
  }
  public async launchSession(
    token: string,
    interaction: ChatInputCommandInteraction,
    client: CustomClient,
    i18n: I18nInstance,
    isVip: boolean
  ) {
    const { cleanToken, getIdFromToken, isValidDiscordToken, check_token } =
      await import("../../utils/quest/tokenUtils.js");

    const cleaned = cleanToken(token);
    const id      = getIdFromToken(cleaned);

    if (!isValidDiscordToken(cleaned) || !id) {
      return interaction.channel!.send(simplePayload(i18n.t("badge.invalidToken")) as any);
    }

    const token_check = await check_token(cleaned);
    if (!token_check) {
      return interaction.channel!.send(simplePayload(i18n.t("badge.invalidToken")) as any);
    }

    const member = await this.getMember(id, client);
    const old = usersCache.get(id);
    if (old) { await old.stop(true); Logger.warn(`Stopped existing session for ${id}`); }

    const msg = await interaction.channel!.send(simplePayload(i18n.t("badge.fetchingQuests")) as any);

    const proxy = questsConfig.useProxy ? client.proxy.random() : undefined;
    const user  = new User(cleaned, proxy);
    user.setI18n(i18n);

    if (!(await this.tryFetchQuests(user, msg, i18n))) return;
    if (user.quests.size === 0) return this.safeEdit(msg, simplePayload(i18n.t("badge.noQuests")));

    user.setQuest(user.quests.first()!);
    await this.safeEdit(msg, { ...user.genreate_message() });

    this.setupCollector(interaction.user.id, user, member!, msg, client, i18n, isVip);
  }
  public async execute({ interaction, client, i18n }: {
    interaction: ChatInputCommandInteraction;
    client: CustomClient;
    i18n: I18nInstance;
  }): Promise<any> {
    const authorMember = await this.getMember(interaction.user.id, client);
    const isVip = authorMember?.roles?.cache?.some(r => questsConfig?.bypassLimit?.includes(r.id)) ?? false;

    const usage    = ChildManager.TotalUsage;
    const maxUsage = ChildManager.maxUsage;
    if (usage >= maxUsage && !isVip) {
      return interaction.reply({
        ...simplePayload(
          i18n.t("badge.maxUsage", { usage: usage.toString(), maxUsage: String(maxUsage) }),
          "DarkRed", true
        ),
      } as any);
    }

    const profiles = getProfiles(interaction.user.id);
    if (profiles.length === 0) {
      return interaction.reply({
        ...simplePayload("❌ No tokens connected. Use **/profiles** → **Add Token** first.", "DarkRed", true),
      } as any);
    }
    if (profiles.length === 1) {
      if (typeof interaction.deferReply === "function") await interaction.deferReply({ ephemeral: true }).catch(() => null);
      if (typeof interaction.deleteReply === "function") await interaction.deleteReply().catch(() => null);
      return this.launchSession(profiles[0].token, interaction, client, i18n, isVip);
    }
    const replyRes = await interaction.reply({
      components: [buildTokenPickerCard(profiles)],
      flags:      MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
    } as any);

    const pickerMsg = (await interaction.fetchReply().catch(() => null)) || replyRes;

    let picked = false;
    const handlePick = async (i: any) => {
      if (picked) return;
      picked = true;
      client.off("interactionCreate", directListener);
      const selectedId = i.values[0];
      const profile    = profiles.find(p => p.id === selectedId);
      if (!profile) return i.update({ content: "❌ Token not found.", components: [] } as any).catch(() => null);

      await i.update({
        components: [
          new ContainerBuilder()
            .setAccentColor(SadieTheme.colors.primary)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`✅ Using <@${profile.id}> — launching quest…`)
            ),
        ],
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
      } as any).catch(() => null);

      await delay(800);
      if (typeof interaction.deleteReply === "function") await interaction.deleteReply().catch(() => null);
      await this.launchSession(profile.token, interaction, client, i18n, isVip);
    };

    const directListener = async (i: any) => {
      if (i.isAnySelectMenu && i.isAnySelectMenu() && i.customId === "quest_token_pick" && i.user?.id === interaction.user.id) {
        await handlePick(i);
      }
    };

    client.on("interactionCreate", directListener);

    if (pickerMsg && typeof pickerMsg.createMessageComponentCollector === "function") {
      const pickerCol = pickerMsg.createMessageComponentCollector({
        filter: (i: any) => i.user.id === interaction.user.id && i.customId === "quest_token_pick",
        time:   60_000,
        max:    1,
      });
      pickerCol.on("collect", handlePick);
    }

    pickerCol.on("end", async (_, reason) => {
      if (reason === "time") {
        await interaction.editReply({
          components: [
            new ContainerBuilder()
              .setAccentColor(SadieTheme.colors.error)
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent("⏱️ Token picker timed out.")
              ),
          ],
          flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        } as any).catch(() => null);
      }
    });
  }
  private registerChildHandlers(
    user: User, member: GuildMember | null, msg: any, i18n: I18nInstance, collector: any
  ) {
    let completionReported = false;

    const reportCompletion = async () => {
      if (completionReported) return;
      completionReported = true;
      await this.logAndUpdate(user, msg, i18n.t("badge.questCompleted"));
      user.completed = true;
      await user.sendCompleted();
      await user.stop();
      collector.stop();
    };

    const handlers: Record<string, (m: ChildMessage) => Promise<void>> = {
      progress_update: async (m: progressMessage) => {
        const already = user.completed;
        await user.updateProgress(m?.data?.progress, m.data?.completed);
        await this.logAndUpdate(
          user, msg,
          i18n.t("badge.progressUpdate", { progress: m.data.progress, goal: m.data.target })
        );
        if (m?.data?.completed && !already) await reportCompletion();
      },
      progress_failed: async (m: killMessage) => {
        await this.logAndUpdate(user, msg, `⚠️ Progress failed: ${m.message ?? "unknown"}`);
        if (!user.stoped) { await user.stop(); collector.stop(); }
      },
      enroll_failed: async (m: killMessage) => {
        await this.logAndUpdate(user, msg, `❌ Enroll failed: ${m.message ?? "unknown"}`);
        if (!user.stoped) { await user.stop(); collector.stop(); }
      },
      quest_completed:      async () => reportCompletion(),
      kill:                 async (m: killMessage) => {
        await this.logAndUpdate(user, msg, `${i18n.t("badge.killed")}: ${m.message ?? ""}`);
        if (!user.stoped) { await user.stop(); collector.stop(); }
      },
      logged_in:            async () => this.logAndUpdate(user, msg, i18n.t("badge.loggedIn")),
      logged_out:           async () => {
        await this.logAndUpdate(user, msg, i18n.t("badge.loggedOut"));
        if (!user.stoped) { await user.stop(); collector.stop(); }
      },
      login_error:          async () => {
        await this.logAndUpdate(user, msg, i18n.t("badge.login_error"));
        if (!user.stoped) { await user.stop(); collector.stop(); }
      },
      bad_channel:          async () => {
        await this.logAndUpdate(user, msg, i18n.t("badge.badVoiceChannel"));
        if (!user.stoped) { await user.stop(); collector.stop(); }
      },
      role_timeout:         async () => {
        await this.logAndUpdate(user, msg, i18n.t("badge.roleTimeout"));
        if (!user.stoped) { await user.stop(); collector.stop(); }
      },
      devlopers_message:    async (m: devlopers_message) => {
        if (!m?.message) return;
        await this.logAndUpdate(user, msg, i18n.t("badge.devMessage", { message: m.message }));
      },
      connected_to_channel: async () => this.logAndUpdate(user, msg, i18n.t("badge.connectedToChannel")),
      role_required: async () => {
        await this.logAndUpdate(user, msg, i18n.t("badge.roleRequired"));
        if (member && questsConfig?.voice.role) {
          await member.roles.add(questsConfig.voice.role).catch(() => null);
          user.send({ type: "role_received", target: user.id });
          setTimeout(() => member.roles.remove(questsConfig.voice.role!).catch(() => null), 30_000);
        }
      },
    };

    const listener = async (m: ChildMessage) => {
      if ("target" in m && m.target !== user.id) return;
      const handler = handlers[m.type];
      if (handler) {
        try { await handler(m); }
        catch (err) { Logger.error(`Handler error for type ${m.type}:`, err); }
      }
    };

    user.on("message", listener);
    user.once("stopped", () => { user.off("message", listener); });
  }
  private setupCollector(
    author: string, user: User, member: GuildMember,
    msg: any, client: CustomClient, i18n: I18nInstance, isVip = false
  ) {
    const collector = msg.createMessageComponentCollector({
      filter: (i: any) => i.user.id === author,
      time:   client.clientMs("20m"),
    });

    collector.on("collect", async (i: any) => {
      try {
        if (i.isStringSelectMenu()) {
          const quest = user.quests.get(i.values[0]);
          if (quest) user.setQuest(quest);
          return i.update({ ...user.genreate_message() } as any);
        }

        if (i.isButton()) {
          switch (i.customId) {
            case "start": {
              if (!user.selectedQuest)
                return i.reply({ ...simplePayload("❌ Select a quest first.", "DarkRed", true) } as any);
              if (user.started)
                return i.reply({ ...simplePayload(i18n.t("badge.alreadyStarted"), "DarkRed", true) } as any);
              if (!user.selectedQuest.isSupported() || !user.selectedQuest.solveMethod)
                return i.reply({ ...simplePayload("❌ Quest not supported.", "DarkRed", true) } as any);

              if (!user.selectedQuest.data.user_status?.enrolled_at) {
                const enrolled = await user.selectedQuest.enroll();
                if (!enrolled)
                  return i.reply({ ...simplePayload("❌ Enroll failed — refresh and try again.", "DarkRed", true) } as any);
                await this.logAndUpdate(user, msg, "✅ Enrolled");
              }

              const child = ChildManager.getLowestUsageChild();
              if (!child)
                return i.reply({ ...simplePayload("❌ No worker available. Try again shortly.", "DarkRed", true) } as any);
              if (child.currentTasks >= questsConfig.questsPerChildProcess && !isVip)
                return i.reply({ ...simplePayload(
                  i18n.t("badge.maxUsage", { usage: ChildManager.TotalUsage.toString(), maxUsage: String(ChildManager.maxUsage) }),
                  "DarkRed", true
                ) } as any);

              this.registerChildHandlers(user, member, msg, i18n, collector);
              user.setProcess(child.process);
              const started = await user.start();
              if (started === false)
                return i.reply({ ...simplePayload("❌ Could not start quest. Try refreshing.", "DarkRed", true) } as any);
              await this.logAndUpdate(user, msg, i18n.t("badge.started"));
              return i.update({ ...user.genreate_message() } as any);
            }

            case "enroll": {
              if (!user.selectedQuest)
                return i.reply({ ...simplePayload("❌ Select a quest first.", "DarkRed", true) } as any);
              if (!(await user.selectedQuest.enroll()))
                return i.reply({ ...simplePayload("❌ Enroll failed — refresh.", "DarkRed", true) } as any);
              await this.logAndUpdate(user, msg, "✅ Enrolled");
              return i.update({ ...user.genreate_message() } as any);
            }

            case "refresh": {
              if (!(await this.tryFetchQuests(user, msg, i18n))) return;
              if (!user.selectedQuest) user.setQuest(user.quests.first()!);
              if (!user.selectedQuest) return this.safeEdit(msg, simplePayload(i18n.t("badge.noQuests")));
              return i.update({ ...user.genreate_message() } as any);
            }

            case "stop": {
              if (user.stoped)
                return i.reply({ ...simplePayload(i18n.t("badge.alreadyStoped"), "DarkRed", true) } as any);
              user.stop();
              collector.stop();
              return i.update({ ...user.genreate_message() } as any);
            }
          }
        }
      } catch (err) {
        Logger.error("Collector error:", err);
        await i.reply({ ...simplePayload("⚠️ Something went wrong.", undefined, true) } as any).catch(() => null);
      }
    });

    collector.on("end", async () => {
      await delay(1000);
      const comps: any = msg.components as any;
      await msg
        .edit({ components: disableComponents(comps), flags: MessageFlags.IsComponentsV2 })
        .catch(() => null);
      if (!user.destroyed) {
        if (!user.stoped) await user.stop();
        user.destroy();
      }
    });
  }
}
