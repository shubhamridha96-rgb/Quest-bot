import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
import config from "../../config/config.js";
import { blacklist, premium, keys, genKey } from "../../core/stores.js";
import { SlashCommandUserOption, SlashCommandStringOption } from "discord.js";
export default class BlacklistAddCommand extends SlashCommand {
  public name="blacklist-add";
  public description="[Owner] Add a user to the blacklist";
  public options=[new SlashCommandUserOption().setName("user").setDescription("User").setRequired(false), new SlashCommandStringOption().setName("key").setDescription("Key").setRequired(false)];
  public async execute({interaction}:any){
    if(!config.developers.includes(interaction.user.id)) return interaction.reply(simplePayload("Owner only", "DarkRed", true) as any);
    let msg="Done"; const n=this.name as string;
    if(n==="blacklist-add"){ const u=interaction.options.getUser("user"); if(u) { blacklist.set(u.id,{reason:"manual",at:Date.now()}); msg="Added "+u.tag+" to blacklist"; } }
    else if(n==="blacklist-remove"){ const u=interaction.options.getUser("user"); if(u) { blacklist.delete(u.id); msg="Removed "+u.tag; } }
    else if(n==="blacklist-list"){ msg=blacklist.size? [...blacklist.keys()].map(k=>"<@"+k+">").join("\n") : "No blacklisted users"; }
    else if(n==="premium-add"){ const u=interaction.options.getUser("user"); if(u){ premium.set(u.id,{since:Date.now(), until:Date.now()+30*24*3600*1000}); msg="Premium added to "+u.tag; } }
    else if(n==="premium-remove"){ const u=interaction.options.getUser("user"); if(u){ premium.delete(u.id); msg="Premium removed"; } }
    else if(n==="premium-list"){ msg=premium.size? [...premium.keys()].map(k=>"<@"+k+">").join("\n") : "No premium users"; }
    else if(n==="generate-keys"){ const k=genKey(); keys.set(k,{key:k,days:30,createdBy:interaction.user.id,createdAt:Date.now()}); msg="Generated: "+k; }
    else if(n==="keys-list"){ msg=keys.size? [...keys.values()].map(k=>k.key+" "+(k.usedBy?"used by <@"+k.usedBy+">":"unused")).join("\n") : "No keys"; }
    else if(n==="key-status"){ const kk=interaction.options.getString("key"); const v=kk?keys.get(kk):null; msg=v? JSON.stringify(v,null,2):"Key not found"; }
    else if(n==="key-delete"){ const kk=interaction.options.getString("key"); if(kk) { keys.delete(kk); msg="Deleted "+kk; } }
    else if(n==="redeem-panel"){ msg="Redeem panel sent! Use /redeem <key>"; }
    await (interaction.deferred || interaction.replied ? interaction.editReply.bind(interaction) : interaction.reply.bind(interaction))(simplePayload(msg) as any);
  }
}
