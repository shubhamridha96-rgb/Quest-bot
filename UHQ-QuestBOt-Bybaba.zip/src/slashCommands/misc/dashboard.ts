import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { ContainerBuilder, TextDisplayBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, MessageFlags } from "discord.js";
import { SadieTheme } from "../../config/theme.js";
export default class DashboardCommand extends SlashCommand {
  public name="dashboard";
  public description="Open the Questy Web Dashboard and Owner Control Panel";
  public async execute({interaction}:any){
    const c=new ContainerBuilder().setAccentColor(SadieTheme.colors.primary).addTextDisplayComponents(new TextDisplayBuilder().setContent("# Questy Dashboard"), new TextDisplayBuilder().setContent("Web dashboard at http://localhost:3001"));
    const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel("Open Dashboard").setStyle(ButtonStyle.Link).setURL("http://localhost:3001"));
    c.addActionRowComponents(row as any);
    await (interaction.deferred || interaction.replied ? interaction.editReply.bind(interaction) : interaction.reply.bind(interaction))({ components:[c], flags: MessageFlags.IsComponentsV2, ephemeral:true } as any);
  }
}
