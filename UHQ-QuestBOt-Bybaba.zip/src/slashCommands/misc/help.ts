import { SlashCommand } from "../../lib/handler/slashCommand.js";
import {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  SectionBuilder,
  ThumbnailBuilder,
  MessageFlags,
} from "discord.js";

export default class HelpCommand extends SlashCommand {
  public name = "help";
  public description = "Show cute compact help menu";

  public async execute({ interaction, client }: any) {
    const reply = (interaction.deferred || interaction.replied)
      ? interaction.editReply.bind(interaction)
      : interaction.reply.bind(interaction);

    const container = new ContainerBuilder().setAccentColor(0x000001);

    const headerSection = new SectionBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `## ✨ Questy • Commands\n*Prefix:* \`!\` · Fast & Automated`
        )
      )
      .setThumbnailAccessory(
        new ThumbnailBuilder()
          .setDescription("Questy")
          .setURL(
            client.user?.displayAvatarURL?.({ size: 64, extension: "png" }) ??
            "https://k.top4top.io/p_3343xcnvn1.png"
          )
      );

    container.addSectionComponents(headerSection);

    container.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );

    const compactText = [
      `\`!link\` · Connect & manage token profiles`,
      `\`!unlink\` · Remove saved account token`,
      `\`!questlist\` · Check supported quests`,
      `\`!complete-quest\` · Complete a specific quest`,
      `\`!complete-all-quests\` · Complete all active quests`,
      `\`!redeem <key>\` · Redeem VIP subscription`,
      `\`!ping\` · Check response speed`,
    ].join("\n");

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(compactText)
    );

    container.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false)
    );

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# 🤍 Type any command above to get started`)
    );

    await reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
    } as any);
  }
}
