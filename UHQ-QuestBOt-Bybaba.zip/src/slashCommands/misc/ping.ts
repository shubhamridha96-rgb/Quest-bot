import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
export default class PingCommand extends SlashCommand {
  public name="ping";
  public description="Check bot latency";
  public async execute({ interaction, client }:any){
    const ms=Date.now()-interaction.createdTimestamp;
    await (interaction.deferred || interaction.replied ? interaction.editReply.bind(interaction) : interaction.reply.bind(interaction))(simplePayload("**Pong!** "+ms+"ms \u2764\uFE0F\u200D\uD83D\uDD25") as any);
  }
}
