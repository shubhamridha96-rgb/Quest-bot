import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, MessageFlags } from "discord.js";
import { SadieTheme } from "../../config/theme.js";
import { SlashCommandStringOption } from "discord.js";
import { getProfiles } from "../../core/tokenStore.js";
import { change_house, houses } from "../../utils/hypesquad.js";

export default class HypesquadCommand extends SlashCommand {
  public name="hypesquad";
  public description="Set or change your Discord HypeSquad House";
  public flags: any[] = ["noReply"];
  public options=[new SlashCommandStringOption().setName("house").setDescription("bravery / brilliance / balance").setRequired(false).addChoices({name:"Bravery",value:"bravery"},{name:"Brilliance",value:"brilliance"},{name:"Balance",value:"balance"})];
  public async execute({interaction}:any){
    const direct=interaction.options.getString("house");
    const profiles=getProfiles(interaction.user.id);
    const send=(c:any)=> (interaction.deferred||interaction.replied? interaction.editReply(c): interaction.reply(c)) as any;

    if(direct && profiles.length>0){
      const p=profiles[0];
      try{ const r=await change_house(p.token, direct); await send({ components:[new ContainerBuilder().setAccentColor(SadieTheme.colors.primary).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# \uD83D\uDD25 HypeSquad — ${direct}`), new TextDisplayBuilder().setContent(r===1? `✅ House **${direct}** set for <@${p.id}>` : "❌ Failed"), new TextDisplayBuilder().setContent(`-# ${SadieTheme.footer.text}`))], flags: MessageFlags.IsComponentsV2 } as any); return; }catch(e:any){ await send({ content:`❌ ${e.message}`, ephemeral:true } as any); return; }
    }
    if(direct && profiles.length===0){
      try{ await send({ content:"No saved token — use /connect-token first or pick a house via the interactive panel.", ephemeral:true } as any); }catch{}
    }

    const container=new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent("# \uD83D\uDD25 HypeSquad House — Sadie Sink Edition"), new TextDisplayBuilder().setContent("Pick your house and the token to apply it to. Uses `POST /hypesquad/online` with your token."));
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
    if(profiles.length===0){
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent("**No tokens connected** — use **/connect-token** or **/profiles** → *Add Token* first."));
    } else {
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`**${profiles.length}** profile(s): ${profiles.map(p=>`<@${p.id}>`).join(", ")}`));
    }
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent("-# Bravery 🔥 • Brilliance 💎 • Balance ⚖️ — Sadie says choose wisely"));

    const rowHouses=new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("hs_bravery").setLabel("Bravery").setStyle(ButtonStyle.Danger).setEmoji("🔥"),
      new ButtonBuilder().setCustomId("hs_brilliance").setLabel("Brilliance").setStyle(ButtonStyle.Primary).setEmoji("💎"),
      new ButtonBuilder().setCustomId("hs_balance").setLabel("Balance").setStyle(ButtonStyle.Success).setEmoji("⚖️"),
    );
    container.addActionRowComponents(rowHouses as any);

    if(profiles.length>0){
      const rowSel=new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId("hs_token").setPlaceholder("Select token to apply").setMinValues(1).setMaxValues(1).addOptions(profiles.map(p=>({ label: (p.username||p.id).slice(0,25), value:p.id, description: `${p.id.slice(0,8)}...` }))) as any
      );
      container.addActionRowComponents(rowSel as any);
    }

    await send({ components:[container], flags: MessageFlags.IsComponentsV2 } as any);
    const msg=await interaction.fetchReply().catch(()=>null);
    if(!msg) return;
    let selectedToken=profiles[0]?.id || null;
    const col=msg.createMessageComponentCollector({ filter:(i:any)=>i.user.id===interaction.user.id, time:120000 });
    col.on("collect", async (i:any)=>{
      if(i.customId==="hs_token"){ selectedToken=i.values[0]; const { simplePayload }=await import("../../lib/handler/componentsV2.js"); await i.reply({ ...simplePayload(`Selected <@${selectedToken}> — now pick a house`, undefined, true) } as any); return; }
      const house=i.customId.replace("hs_","");
      if(!houses.includes(house as any)) return;
      const profile=profiles.find(p=>p.id===selectedToken) || profiles[0];
      if(!profile) { const { simplePayload }=await import("../../lib/handler/componentsV2.js"); return i.reply({ ...simplePayload("❌ No token — add one via /connect-token", "DarkRed", true) } as any); }
      await i.deferReply({ ephemeral:true } as any);
      try{
        const r=await change_house(profile.token, house);
        const { simplePayload }=await import("../../lib/handler/componentsV2.js");
        await i.editReply(simplePayload(r===1? `✅ **${house}** house set for <@${profile.id}>` : "❌ Failed", undefined, true) as any);
        const done=new ContainerBuilder().setAccentColor(SadieTheme.colors.primary).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ✅ House ${house} applied`), new TextDisplayBuilder().setContent(`Token <@${profile.id}> → **${house}**`), new TextDisplayBuilder().setContent(`-# ${SadieTheme.footer.text}`));
        await interaction.editReply({ components:[done], flags: MessageFlags.IsComponentsV2 } as any);
        col.stop();
      }catch(e:any){
        const { simplePayload }=await import("../../lib/handler/componentsV2.js");
        await i.editReply(simplePayload(`❌ Error: ${e.message}`, "DarkRed", true) as any);
      }
    });
    col.on("end", async()=>{ try{ const {disableComponents}=await import("../../utils/tools.js"); await interaction.editReply({ components: disableComponents((await interaction.fetchReply()).components as any), flags: MessageFlags.IsComponentsV2 } as any);}catch{} });
  }
}
