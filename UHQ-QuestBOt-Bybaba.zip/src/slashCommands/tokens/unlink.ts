import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { ContainerBuilder, TextDisplayBuilder, ActionRowBuilder, StringSelectMenuBuilder, MessageFlags } from "discord.js";
import { SadieTheme } from "../../config/theme.js";
import { getProfiles, removeProfile } from "../../core/tokenStore.js";
export default class UnlinkCommand extends SlashCommand {
  public name="unlink";
  public description="Remove your saved Discord token(s)";
  public async execute({interaction}:any){
    const list=getProfiles(interaction.user.id);
    if(!list.length) return (interaction.deferred||interaction.replied? interaction.editReply.bind(interaction):interaction.reply.bind(interaction))({ components:[new ContainerBuilder().setAccentColor(SadieTheme.colors.primary).addTextDisplayComponents(new TextDisplayBuilder().setContent("No tokens"))], flags: MessageFlags.IsComponentsV2 } as any);
    const c=new ContainerBuilder().setAccentColor(SadieTheme.colors.primary).addTextDisplayComponents(new TextDisplayBuilder().setContent("Select token to unlink"));
    const row=new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId("unlink_select").setPlaceholder("Choose").addOptions(list.map(p=>({label:p.id.slice(0,20), value:p.id}))) as any);
    c.addActionRowComponents(row as any);
    await (interaction.deferred||interaction.replied? interaction.editReply.bind(interaction):interaction.reply.bind(interaction))({ components:[c], flags: MessageFlags.IsComponentsV2 } as any);
    const msg=await interaction.fetchReply().catch(()=>null);
    if(!msg) return;
    const col=msg.createMessageComponentCollector({ filter:(i)=>i.user.id===interaction.user.id, time:60000 });
    col.on("collect", async(i)=>{ const id=i.values[0]; removeProfile(interaction.user.id,id); await i.update({ content:"🗑 Removed", components:[] } as any); col.stop(); });
  }
}
