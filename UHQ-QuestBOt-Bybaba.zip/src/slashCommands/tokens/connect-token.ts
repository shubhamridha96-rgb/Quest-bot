import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } from "discord.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
export default class ConnectTokenCommand extends SlashCommand {
  public name="connect-token";
  public description="Connect a new Discord Token (up to 5 accounts for Premium users)";
  public flags: any[] = ["noReply"];
  public async execute({interaction}:any){
    const modal=new ModalBuilder().setCustomId("connect_modal").setTitle("Connect Token");
    modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("token").setLabel("Discord Token").setStyle(TextInputStyle.Paragraph).setRequired(true)) as any);
    await interaction.showModal(modal);
    try{
      const m=await interaction.awaitModalSubmit({ time:60000, filter:(x)=>x.user.id===interaction.user.id });
      const raw=m.fields.getTextInputValue("token");
      const { addProfile }=await import("../../core/tokenStore.js");
      const r=addProfile(interaction.user.id, raw);
      await m.reply({ content: r.ok? "<a:emoji_7:1571194594400407732> Connected <@"+r.profile.id+">" : "❌ "+r.error, ephemeral:true } as any);
    }catch{}
  }
}
