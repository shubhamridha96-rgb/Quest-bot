import { SlashCommand } from "../../lib/handler/slashCommand.js";
import {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  SectionBuilder,
  ThumbnailBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} from "discord.js";
import { SadieTheme } from "../../config/theme.js";
import {
  getProfiles,
  mask,
  validateProfile,
  removeProfile,
} from "../../core/tokenStore.js";

const MAX_SLOTS  = 3;          // display cap shown in the card (cosmetic)
const IDLE_MS    = 120_000;

export default class ProfilesCommand extends SlashCommand {
  public name        = "profiles";
  public description = "View token profile dashboard with Set/Replace/Remove buttons and Modals";

  public async execute({ interaction }: any) {
    const profiles = getProfiles(interaction.user.id);

    const send = (payload: any) =>
      (interaction.deferred || interaction.replied
        ? interaction.editReply(payload)
        : interaction.reply(payload)) as Promise<any>;
    const buildCard = (): any => {
      const container = new ContainerBuilder()
        .setAccentColor(SadieTheme.colors.primary);
      const headerText = [
        "# 💳  User Token Profiles",
        `**User:** <@${interaction.user.id}>`,
        `**Subscription:** Normal ${SadieTheme.emojis.star}`,
        `**Connected Slots:** ${profiles.length} / ${MAX_SLOTS}`,
      ].join("\n");

      const headerSection = new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(headerText)
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder()
            .setDescription("Questy avatar")
            .setURL(
              interaction.user.displayAvatarURL?.({ size: 128, extension: "png" }) ??
              SadieTheme.banners.fallback
            )
        );

      container.addSectionComponents(headerSection);
      container.addSeparatorComponents(
        new SeparatorBuilder()
          .setSpacing(SeparatorSpacingSize.Small)
          .setDivider(true)
      );
      if (profiles.length === 0) {
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `> You currently have **0** accounts connected.\n>\n> Click **Add Token** below to connect your first Discord Token.`
          )
        );
      } else {
        const lines = profiles.map((p, i) => {
          const status = p.valid === false ? "❌ Invalid" : `<a:emoji_7:1571194594400407732> ${p.username ?? "Unknown"}`;
          return `> **#${i + 1}** <@${p.id}> \`${mask(p.token)}\` — ${status}`;
        });

        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(lines.join("\n"))
        );

        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `-# ${profiles.length}/${MAX_SLOTS} slots used`
          )
        );
      }
      container.addSeparatorComponents(
        new SeparatorBuilder()
          .setSpacing(SeparatorSpacingSize.Small)
          .setDivider(false)
      );
      const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("profiles_add")
          .setLabel("Add Token")
          .setStyle(ButtonStyle.Success)
          .setEmoji("➕"),
        new ButtonBuilder()
          .setCustomId("profiles_refresh")
          .setLabel("Refresh")
          .setStyle(ButtonStyle.Secondary)
          .setEmoji("🔄"),
      );

      container.addActionRowComponents(row1 as any);
      if (profiles.length > 0) {
        const menu = new StringSelectMenuBuilder()
          .setCustomId("profiles_select")
          .setPlaceholder("Select a profile to manage…")
          .setMinValues(1)
          .setMaxValues(1);

        profiles.forEach(p =>
          menu.addOptions({
            label:       (p.username ?? p.id).slice(0, 25),
            value:       p.id,
            description: mask(p.token).slice(0, 30),
            emoji:       p.valid === false ? "❌" : "✅",
          })
        );

        const row2 = new ActionRowBuilder().addComponents(menu as any);
        container.addActionRowComponents(row2 as any);
      }
      container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text} ${SadieTheme.emojis.max}`
        )
      );

      return { components: [container], flags: MessageFlags.IsComponentsV2 };
    };
    await send(buildCard());

    const msg = await interaction.fetchReply().catch(() => null);
    if (!msg) return;
    const col = msg.createMessageComponentCollector({
      filter: (i: any) => i.user.id === interaction.user.id,
      time:   IDLE_MS,
    });

    col.on("collect", async (i: any) => {
      if (i.customId === "profiles_add") {
        const modal = new ModalBuilder()
          .setCustomId("profiles_modal_add")
          .setTitle("Connect Token");

        modal.addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder()
              .setCustomId("token")
              .setLabel("Discord Token")
              .setStyle(TextInputStyle.Paragraph)
              .setRequired(true)
          ) as any
        );

        await i.showModal(modal);

        try {
          const m = await i.awaitModalSubmit({
            time:   60_000,
            filter: (x: any) => x.user.id === interaction.user.id,
          });

          const raw = m.fields.getTextInputValue("token");
          const { addProfile } = await import("../../core/tokenStore.js");
          const result = addProfile(interaction.user.id, raw);

          await m.reply({
            content:   result.ok
              ? `✅ Connected <@${result.profile!.id}>`
              : `❌ ${result.error}`,
            ephemeral: true,
          } as any);

          if (result.ok) {
            const fresh = getProfiles(interaction.user.id);
            profiles.splice(0, profiles.length, ...fresh);
            await interaction.editReply(buildCard());
          }
        } catch {  }
        return;
      }
      if (i.customId === "profiles_refresh") {
        for (const p of profiles) await validateProfile(p);
        await i.update(buildCard());
        return;
      }
      if (i.customId === "profiles_select") {
        const id = i.values[0];
        const manageRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`profiles_check_${id}`)
            .setLabel("Check")
            .setStyle(ButtonStyle.Secondary)
            .setEmoji("🔍"),
          new ButtonBuilder()
            .setCustomId(`profiles_disconnect_${id}`)
            .setLabel("Disconnect")
            .setStyle(ButtonStyle.Danger)
            .setEmoji("🗑️"),
        );

        await i.reply({
          content:    `Manage <@${id}>`,
          components: [manageRow as any],
          ephemeral:  true,
        } as any);
        return;
      }
      if (i.customId.startsWith("profiles_check_")) {
        const id = i.customId.replace("profiles_check_", "");
        const p  = profiles.find(x => x.id === id);
        if (!p) return i.reply({ content: "Profile not found.", ephemeral: true } as any);

        await validateProfile(p);
        await i.reply({
          content:   p.valid ? `✅ Valid — ${p.username ?? "Unknown"}` : "❌ Token is invalid",
          ephemeral: true,
        } as any);
        await interaction.editReply(buildCard());
        return;
      }
      if (i.customId.startsWith("profiles_disconnect_")) {
        const id = i.customId.replace("profiles_disconnect_", "");
        removeProfile(interaction.user.id, id);
        profiles.splice(profiles.findIndex(x => x.id === id), 1);

        await i.reply({
          content:   `🗑️ Removed <@${id}>`,
          ephemeral: true,
        } as any);
        await interaction.editReply(buildCard());
        return;
      }
    });
    col.on("end", async () => {
      try {
        const { disableComponents } = await import("../../utils/tools.js");
        const current = await interaction.fetchReply();
        await interaction.editReply({
          components: disableComponents(current.components as any),
          flags:      MessageFlags.IsComponentsV2,
        } as any);
      } catch {  }
    });
  }
}
