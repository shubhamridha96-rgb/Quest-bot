import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { ContainerBuilder, TextDisplayBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } from "discord.js";
import { SadieTheme } from "../../config/theme.js";
import { getProfiles, mask } from "../../core/tokenStore.js";
export default class TokensCommand extends SlashCommand {
  public name="tokens";
  public description="View and manage your connected account token profiles";
  public async execute({interaction}:any){
    const list=getProfiles(interaction.user.id);
    const c=new ContainerBuilder().setAccentColor(SadieTheme.colors.primary).addTextDisplayComponents(new TextDisplayBuilder().setContent("# Tokens "+list.length+"/1"), new TextDisplayBuilder().setContent(list.length? list.map((p,i)=>"**"+(i+1)+"** <@"+p.id+"> • "+mask(p.token)).join("\n") : "No tokens — use /connect-token or /profiles"), new TextDisplayBuilder().setContent("-# "+SadieTheme.footer.text));
    const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("tokens_profiles").setLabel("Open Profiles").setStyle(ButtonStyle.Primary));
    c.addActionRowComponents(row as any);
    await (interaction.deferred||interaction.replied? interaction.editReply.bind(interaction) : interaction.reply.bind(interaction))({ components:[c], flags: MessageFlags.IsComponentsV2 } as any);
  }
}
