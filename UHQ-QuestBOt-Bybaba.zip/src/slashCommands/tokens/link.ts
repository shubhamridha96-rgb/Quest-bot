import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } from "discord.js";
export default class LinkCommand extends SlashCommand {
  public name="link";
  public description="Connect your Discord token";
  public flags: any[] = ["noReply"];
  public async execute({interaction}:any){
    const modal=new ModalBuilder().setCustomId("link_modal").setTitle("Link Token");
    modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("token").setLabel("Token").setStyle(TextInputStyle.Paragraph).setRequired(true)) as any);
    await interaction.showModal(modal);
    try{
      const m=await interaction.awaitModalSubmit({ time:60000, filter:(x)=>x.user.id===interaction.user.id });
      const { addProfile }=await import("../../core/tokenStore.js");
      const r=addProfile(interaction.user.id, m.fields.getTextInputValue("token"));
      await m.reply({ content: r.ok? "<a:emoji_7:1571194594400407732> Linked" : "❌ "+r.error, ephemeral:true } as any);
    }catch{}
  }
}
