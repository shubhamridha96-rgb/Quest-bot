import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { getProfiles, removeProfile } from "../../core/tokenStore.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
import { SlashCommandStringOption } from "discord.js";
export default class DisconnectTokenCommand extends SlashCommand {
  public name="disconnect-token";
  public description="Remove token(s) from database";
  public options=[new SlashCommandStringOption().setName("id").setDescription("User ID of token").setRequired(true)];
  public async execute({interaction}:any){
    const id=interaction.options.getString("id",true);
    const ok=removeProfile(interaction.user.id,id);
    await (interaction.deferred||interaction.replied? interaction.editReply.bind(interaction):interaction.reply.bind(interaction))(simplePayload(ok?"Removed":"Not found") as any);
  }
}
