import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
import { getProfiles, validateProfile } from "../../core/tokenStore.js";
export default class TokencheckCommand extends SlashCommand {
  public name="tokencheck";
  public description="Check whether your saved Discord token is still valid";
  public async execute({interaction}:any){
    const list=getProfiles(interaction.user.id);
    if(!list.length) return (interaction.deferred||interaction.replied? interaction.editReply.bind(interaction):interaction.reply.bind(interaction))(simplePayload("No tokens saved") as any);
    let out="";
    for(const p of list){ await validateProfile(p); out+= (p.valid?"\u2705":"\u274C")+" <@"+p.id+">\n"; }
    await (interaction.deferred||interaction.replied? interaction.editReply.bind(interaction):interaction.reply.bind(interaction))(simplePayload(out||"Done") as any);
  }
}
