import { ChatInputCommandInteraction } from "discord.js";
import { SlashCommand, slashCommandFlags } from "../../lib/handler/slashCommand.js";
import { CustomClient } from "../../core/customClient.js";
import { I18nInstance } from "../../core/i18n.js";
import { permissionList } from "../../lib/handler/messageCommand.js";
import BadgeCommand from "../badge/badge.js";

export default class CompleteQuestsCommand extends SlashCommand {
  public name        = "complete-quests";
  public description = "Select an account and choose a quest to complete";
  public options     = [];
  public cooldown: number | string     = "1m";
  public permissions: permissionList[] = [];
  public flags: slashCommandFlags[]    = ["noReply"];

  private badge = new BadgeCommand();

  public async execute(ctx: {
    interaction: ChatInputCommandInteraction;
    client: CustomClient;
    i18n: I18nInstance;
  }): Promise<any> {
    (this.badge as any).client = ctx.client;
    return this.badge.execute(ctx as any);
  }
}
