import {
  ChatInputCommandInteraction,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} from "discord.js";
import { SlashCommand, slashCommandFlags } from "../../lib/handler/slashCommand.js";
import { CustomClient } from "../../core/customClient.js";
import { I18nInstance } from "../../core/i18n.js";
import { permissionList } from "../../lib/handler/messageCommand.js";
import { getProfiles } from "../../core/tokenStore.js";
import { User } from "../../lib/quest/User.js";
import { Quest } from "../../lib/quest/Quest.js";
import { ChildManager } from "../../core/ChildManager.js";
import { usersCache } from "../../core/cache.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
import { isPremium } from "../../core/stores.js";
import questsConfig from "../../config/questsConfig.js";
import { delay } from "../../utils/tools.js";
import { SadieTheme } from "../../config/theme.js";

type TokenStatus = "queued" | "running" | "done" | "partial" | "failed";
type QuestStatus = "queued" | "running" | "done" | "failed";

interface TokenRun {
  id:       string;
  status:   TokenStatus;
  done:     number;
  failed:   number;
  total:    number;
  quests:   { name: string; status: QuestStatus }[];
}

function buildMultiCard(runs: TokenRun[]): any {
  const c = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);
  c.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`# <a:emoji_5:1571194469263483051> Complete All Quests — ${runs.length} Account${runs.length > 1 ? "s" : ""}`)
  );
  c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));

  const icons = { queued: "<a:emoji_1:1571194155403706388>", running: "<a:emoji_3:1571194376304988250>", done: "<a:emoji_7:1571194594400407732>", partial: "⚠️", failed: "❌" };
  const qIcons = { queued: "<a:emoji_1:1571194155403706388>", running: "<a:emoji_3:1571194376304988250>", done: "<a:emoji_7:1571194594400407732>", failed: "❌" };

  for (const run of runs) {
    const lines = [`> ${icons[run.status]} **<@${run.id}>** — ${run.done}/${run.total} quests`];
    if (run.status === "running") {
      run.quests.forEach(q => lines.push(`>   ${qIcons[q.status]} \`${q.name.slice(0, 35)}\``));
    }
    c.addTextDisplayComponents(new TextDisplayBuilder().setContent(lines.join("\n")));
  }

  c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
  c.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text}`)
  );
  return { components: [c], flags: MessageFlags.IsComponentsV2 };
}

export default class CompleteAllQuestsCommand extends SlashCommand {
  public name        = "complete-all-quests";
  public description = "[Premium] Automatically run all available quests across all your saved accounts";
  public options     = [];
  public cooldown: number | string     = "5m";
  public permissions: permissionList[] = [];
  public flags: slashCommandFlags[]    = ["noReply"];

  public async execute({ interaction, client, i18n }: {
    interaction: ChatInputCommandInteraction;
    client: CustomClient;
    i18n: I18nInstance;
  }): Promise<any> {
    if (!isPremium(interaction.user.id) && !questsConfig.bypassLimit?.includes(interaction.user.id)) {
      return interaction.reply({
        ...simplePayload("⭐ **/complete-all-quests** requires **Premium**. Use `/redeem <key>` to activate.", "DarkRed", true),
      } as any);
    }

    const profiles = getProfiles(interaction.user.id);
    if (profiles.length === 0) {
      return interaction.reply({
        ...simplePayload("❌ No tokens connected. Use **/profiles** → **Add Token** first.", "DarkRed", true),
      } as any);
    }

    if (typeof interaction.deferReply === "function") await interaction.deferReply({ ephemeral: true }).catch(() => null);
    if (typeof interaction.deleteReply === "function") await interaction.deleteReply().catch(() => null);

    const { cleanToken, getIdFromToken, isValidDiscordToken, check_token } =
      await import("../../utils/quest/tokenUtils.js");
    const runs: TokenRun[] = profiles.map(p => ({
      id: p.id, status: "queued", done: 0, failed: 0, total: 0, quests: [],
    }));

    const msg = await interaction.channel!.send(buildMultiCard(runs));

    const child = ChildManager.getLowestUsageChild();
    if (!child) return msg.edit(simplePayload("❌ No worker available — try again shortly.") as any);
    for (let ri = 0; ri < profiles.length; ri++) {
      const profile = profiles[ri];
      const run     = runs[ri];

      run.status = "running";
      await msg.edit(buildMultiCard(runs)).catch(() => null);

      const cleaned = cleanToken(profile.token);
      const id      = getIdFromToken(cleaned);
      if (!isValidDiscordToken(cleaned) || !id || !(await check_token(cleaned).catch(() => false))) {
        run.status = "failed";
        await msg.edit(buildMultiCard(runs)).catch(() => null);
        continue;
      }

      const old = usersCache.get(id);
      if (old) await old.stop(true);

      const proxy = questsConfig.useProxy ? client.proxy.random() : undefined;
      const user  = new User(cleaned, proxy);
      user.setI18n(i18n);

      const fetchedQuests = await user.fetchQuests().catch(() => null);
      if (!fetchedQuests || fetchedQuests.size === 0) {
        run.status = "done";
        await msg.edit(buildMultiCard(runs)).catch(() => null);
        continue;
      }

      const queue: Quest[] = [];
      for (const [, q] of fetchedQuests) {
        if (!q.isCompleted() && q.isSupported()) queue.push(q);
      }

      run.total  = queue.length;
      run.quests = queue.map(q => ({ name: q.displayLabel, status: "queued" as QuestStatus }));
      await msg.edit(buildMultiCard(runs)).catch(() => null);

      if (queue.length === 0) {
        run.status = "done";
        await msg.edit(buildMultiCard(runs)).catch(() => null);
        continue;
      }

      for (let qi = 0; qi < queue.length; qi++) {
        const quest = queue[qi];
        run.quests[qi].status = "running";
        await msg.edit(buildMultiCard(runs)).catch(() => null);

        user.setQuest(quest);

        if (!quest.data.user_status?.enrolled_at) {
          const enrolled = await quest.enroll();
          if (!enrolled) { run.quests[qi].status = "failed"; run.failed++; continue; }
        }

        user.setProcess(child.process);

        const ok: boolean = await new Promise(resolve => {
          const finish = (v: boolean) => {
            user.off("message", onMsg);
            user.removeAllListeners("stopped");
            resolve(v);
          };
          const onMsg = (m: any) => {
            if ("target" in m && m.target !== user.id) return;
            if (m.type === "quest_completed" || (m.type === "progress_update" && m.data?.completed)) finish(true);
            else if (["kill","progress_failed","enroll_failed","login_error","logged_out"].includes(m.type)) finish(false);
          };
          user.on("message", onMsg);
          user.once("stopped", () => finish(false));
          user.start().then(s => { if (s === false) finish(false); });
          setTimeout(() => finish(false), 20 * 60 * 1000);
        });

        run.quests[qi].status = ok ? "done" : "failed";
        if (ok) { run.done++; await user.sendCompleted().catch(() => null); }
        else run.failed++;

        await msg.edit(buildMultiCard(runs)).catch(() => null);

        if (qi < queue.length - 1) {
          user.started   = false;
          user.stoped    = false;
          user.completed = false;
          user.logs      = [];
          await delay(3_000);
        }
      }

      run.status = run.failed === 0 ? "done" : run.done > 0 ? "partial" : "failed";
      await msg.edit(buildMultiCard(runs)).catch(() => null);

      user.stop(true);
      user.destroy();

      if (ri < profiles.length - 1) await delay(5_000);
    }
    const totalDone   = runs.reduce((a, r) => a + r.done,   0);
    const totalFailed = runs.reduce((a, r) => a + r.failed, 0);
    const summary = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);
    summary.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# ✅ Complete All — Finished`),
      new TextDisplayBuilder().setContent(
        `**${profiles.length}** account${profiles.length > 1 ? "s" : ""} processed.\n` +
        `✅ Completed: **${totalDone}** | ❌ Failed: **${totalFailed}**`
      )
    );
    summary.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
    summary.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text}`)
    );
    await msg.edit({ components: [summary], flags: MessageFlags.IsComponentsV2 }).catch(() => null);
  }
}
