import {
  ChatInputCommandInteraction,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} from "discord.js";
import { SlashCommand, slashCommandFlags } from "../../lib/handler/slashCommand.js";
import { CustomClient } from "../../core/customClient.js";
import { I18nInstance } from "../../core/i18n.js";
import { permissionList } from "../../lib/handler/messageCommand.js";
import { getProfiles, mask } from "../../core/tokenStore.js";
import { User } from "../../lib/quest/User.js";
import { Quest } from "../../lib/quest/Quest.js";
import { ChildManager } from "../../core/ChildManager.js";
import { usersCache } from "../../core/cache.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
import questsConfig from "../../config/questsConfig.js";
import { Logger } from "../../core/logger.js";
import { delay, disableComponents } from "../../utils/tools.js";
import { SadieTheme } from "../../config/theme.js";
import { buildTokenPickerCard } from "../badge/badge.js";
function buildStatusCard(
  profileLabel: string,
  quests: { id: string; name: string; status: "queued" | "running" | "done" | "failed" | "skipped" }[]
): any {
  const c = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);
  c.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`# <a:emoji_5:1571194469263483051> Quest All — ${profileLabel}`),
    new TextDisplayBuilder().setContent(`Running **${quests.length}** quest${quests.length !== 1 ? "s" : ""} sequentially.`)
  );
  c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));

  const icons = {
    queued:  "<a:emoji_1:1571194155403706388>",
    running: "<a:emoji_3:1571194376304988250>",
    done:    "<a:emoji_7:1571194594400407732>",
    failed:  "❌",
    skipped: "⏭️"
  };
  const lines = quests.map(q => `> ${icons[q.status]} \`${q.name.slice(0, 40)}\``).join("\n");
  c.addTextDisplayComponents(new TextDisplayBuilder().setContent(lines || "> No quests."));

  c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
  c.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text}`)
  );
  return { components: [c], flags: MessageFlags.IsComponentsV2 };
}

export default class QuestallCommand extends SlashCommand {
  public name        = "questall";
  public description = "Complete all available quests at once for a selected account";
  public options     = [];
  public cooldown: number | string     = "2m";
  public permissions: permissionList[] = [];
  public flags: slashCommandFlags[]    = ["noReply"];

  public async execute({ interaction, client, i18n }: {
    interaction: ChatInputCommandInteraction;
    client: CustomClient;
    i18n: I18nInstance;
  }): Promise<any> {
    const profiles = getProfiles(interaction.user.id);

    if (profiles.length === 0) {
      return interaction.reply({
        ...simplePayload("❌ No tokens connected. Use **/profiles** → **Add Token** first.", "DarkRed", true),
      } as any);
    }
    let selectedToken = profiles[0].token;
    let selectedLabel = `<@${profiles[0].id}>`;

    if (profiles.length > 1) {
      const replyResult = await interaction.reply({
        components: [buildTokenPickerCard(profiles)],
        flags:      MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
      } as any);

      const pickerMsg = (await interaction.fetchReply().catch(() => null)) || replyResult;

      const selected: { token: string; label: string } | null = await new Promise(resolve => {
        let done = false;
        const handlePick = async (i: any) => {
          if (done) return;
          done = true;
          client.off("interactionCreate", directListener);
          const p = profiles.find(x => x.id === i.values[0]);
          if (!p) { resolve(null); return; }
          await i.update({
            components: [
              new ContainerBuilder()
                .setAccentColor(SadieTheme.colors.primary)
                .addTextDisplayComponents(
                  new TextDisplayBuilder().setContent(`✅ Using <@${p.id}> — fetching quests…`)
                ),
            ],
            flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
          } as any).catch(() => null);
          resolve({ token: p.token, label: `<@${p.id}>` });
        };

        const directListener = async (i: any) => {
          if (i.isAnySelectMenu && i.isAnySelectMenu() && i.customId === "quest_token_pick" && i.user?.id === interaction.user.id) {
            await handlePick(i);
          }
        };

        client.on("interactionCreate", directListener);

        if (pickerMsg && typeof pickerMsg.createMessageComponentCollector === "function") {
          const col = pickerMsg.createMessageComponentCollector({
            filter: (i: any) => i.user.id === interaction.user.id && i.customId === "quest_token_pick",
            time: 60_000,
            max:  1,
          });
          col.on("collect", handlePick);
        }

        setTimeout(() => {
          if (!done) {
            done = true;
            client.off("interactionCreate", directListener);
            resolve(null);
          }
        }, 60_000);
      });

      if (!selected) {
        return interaction.editReply({
          ...simplePayload("⏱️ Timed out.", "DarkRed"),
        } as any).catch(() => null);
      }
      selectedToken = selected.token;
      selectedLabel = selected.label;
      await delay(600);
      if (typeof interaction.deleteReply === "function") await interaction.deleteReply().catch(() => null);
    }
    const { cleanToken, getIdFromToken, isValidDiscordToken, check_token } =
      await import("../../utils/quest/tokenUtils.js");

    const cleaned = cleanToken(selectedToken);
    const id      = getIdFromToken(cleaned);
    if (!isValidDiscordToken(cleaned) || !id) {
      return interaction.channel!.send(simplePayload(i18n.t("badge.invalidToken")) as any);
    }
    if (!(await check_token(cleaned))) {
      return interaction.channel!.send(simplePayload(i18n.t("badge.invalidToken")) as any);
    }

    const old = usersCache.get(id);
    if (old) { await old.stop(true); }

    const proxy = questsConfig.useProxy ? client.proxy.random() : undefined;
    const user  = new User(cleaned, proxy);
    user.setI18n(i18n);

    const msg = await interaction.channel!.send(
      simplePayload(`🔍 Fetching quests for ${selectedLabel}…`) as any
    );

    const fetchedQuests = await user.fetchQuests().catch(() => null);
    if (!fetchedQuests || fetchedQuests.size === 0) {
      return msg.edit(simplePayload(i18n.t("badge.noQuests")) as any);
    }
    const queue: Quest[] = [];
    for (const [, q] of fetchedQuests) {
      if (!q.isCompleted() && q.isSupported()) queue.push(q);
    }

    if (queue.length === 0) {
      return msg.edit(simplePayload("✅ All supported quests already completed — nothing to run.") as any);
    }

    const statusList = queue.map(q => ({
      id:     q.id,
      name:   q.displayLabel,
      status: "queued" as const,
    }));

    await msg.edit(buildStatusCard(selectedLabel, statusList));

    const child = ChildManager.getLowestUsageChild();
    if (!child) return msg.edit(simplePayload("❌ No worker available — try again shortly.") as any);
    for (let idx = 0; idx < queue.length; idx++) {
      const quest = queue[idx];
      statusList[idx].status = "running";
      await msg.edit(buildStatusCard(selectedLabel, statusList)).catch(() => null);

      user.setQuest(quest);
      if (!quest.data.user_status?.enrolled_at) {
        const enrolled = await quest.enroll();
        if (!enrolled) { statusList[idx].status = "failed"; continue; }
      }

      user.setProcess(child.process);

      const success: boolean = await new Promise(resolve => {
        const done = (ok: boolean) => {
          user.off("message", onMsg);
          user.removeAllListeners("stopped");
          resolve(ok);
        };

        const onMsg = async (m: any) => {
          if ("target" in m && m.target !== user.id) return;
          if (m.type === "quest_completed" || m.type === "progress_update" && m.data?.completed) {
            done(true);
          } else if (["kill", "progress_failed", "enroll_failed", "login_error", "logged_out"].includes(m.type)) {
            done(false);
          }
        };

        user.on("message", onMsg);
        user.once("stopped", () => done(false));

        user.start().then(started => {
          if (started === false) done(false);
        });
        setTimeout(() => done(false), 20 * 60 * 1000);
      });

      statusList[idx].status = success ? "done" : "failed";
      await msg.edit(buildStatusCard(selectedLabel, statusList)).catch(() => null);

      if (success) await user.sendCompleted().catch(() => null);
      if (idx < queue.length - 1) {
        user.started  = false;
        user.stoped   = false;
        user.completed = false;
        user.logs     = [];
        await delay(3_000);
      }
    }
    const done  = statusList.filter(q => q.status === "done").length;
    const failed = statusList.filter(q => q.status === "failed").length;
    const summary = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);
    summary.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# <a:emoji_7:1571194594400407732> Quest All — Complete`),
      new TextDisplayBuilder().setContent(
        `> **${selectedLabel}**\n> <a:emoji_7:1571194594400407732> Completed: **${done}** | ❌ Failed: **${failed}**`
      )
    );
    summary.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
    summary.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text}`)
    );
    await msg.edit({ components: [summary], flags: MessageFlags.IsComponentsV2 }).catch(() => null);

    user.stop(true);
    user.destroy();
  }
}
