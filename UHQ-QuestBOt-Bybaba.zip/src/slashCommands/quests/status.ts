import {
  ChatInputCommandInteraction,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} from "discord.js";
import { SlashCommand, slashCommandFlags } from "../../lib/handler/slashCommand.js";
import { CustomClient } from "../../core/customClient.js";
import { I18nInstance } from "../../core/i18n.js";
import { permissionList } from "../../lib/handler/messageCommand.js";
import { getProfiles } from "../../core/tokenStore.js";
import { User } from "../../lib/quest/User.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
import questsConfig from "../../config/questsConfig.js";
import { SadieTheme } from "../../config/theme.js";

export default class StatusCommand extends SlashCommand {
  public name        = "status";
  public description = "Check your Discord quests status — view completed and incomplete quests";
  public options     = [];
  public cooldown: number | string     = "5s";
  public permissions: permissionList[] = [];
  public flags: slashCommandFlags[]    = ["noReply"];

  public async execute({ interaction, client, i18n }: {
    interaction: ChatInputCommandInteraction;
    client: CustomClient;
    i18n: I18nInstance;
  }): Promise<any> {
    const profiles = getProfiles(interaction.user.id);

    if (profiles.length === 0) {
      return interaction.reply({
        ...simplePayload("❌ No tokens connected. Use **.link** or **/profiles** to connect your account first.", "DarkRed", true),
      } as any);
    }

    const profile = profiles[0];
    const { cleanToken, getIdFromToken, isValidDiscordToken, check_token } =
      await import("../../utils/quest/tokenUtils.js");

    const cleaned = cleanToken(profile.token);
    const id      = getIdFromToken(cleaned);
    if (!isValidDiscordToken(cleaned) || !id || !(await check_token(cleaned))) {
      return interaction.reply({
        ...simplePayload("❌ Connected token is invalid or expired. Re-add it using **.link**.", "DarkRed", true),
      } as any);
    }

    await interaction.reply({
      ...simplePayload(`🔍 Fetching quest status for <@${profile.id}>…`, "Blurple"),
    } as any);

    const proxy = questsConfig.useProxy ? client.proxy.random() : undefined;
    const user  = new User(cleaned, proxy);
    user.setI18n(i18n);

    const quests = await user.fetchQuests().catch(() => null);
    if (!quests || quests.size === 0) {
      const emptyContainer = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);
      emptyContainer.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# 📊 Quests Status — <@${profile.id}>`),
        new TextDisplayBuilder().setContent("> No active quests found on this account.")
      );
      return interaction.editReply({ components: [emptyContainer], flags: MessageFlags.IsComponentsV2 } as any);
    }

    const completedList: string[] = [];
    const incompleteList: string[] = [];

    for (const [, q] of quests) {
      const label = `\`${q.displayLabel.slice(0, 38)}\``;
      if (q.isCompleted()) {
        completedList.push(`> ✅ ${label} — **Completed**`);
      } else {
        const topTask = q.progress[0];
        const pct = topTask ? `${topTask.percent}%` : "0%";
        incompleteList.push(`> ⏳ ${label} — \`${pct}\``);
      }
    }

    const total = quests.size;
    const cCount = completedList.length;
    const iCount = incompleteList.length;

    const c = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);
    c.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# 📊 Quests Status — <@${profile.id}>`),
      new TextDisplayBuilder().setContent(`Total Active: **${total}** | Completed: **${cCount}** ✅ | Incomplete: **${iCount}** ⏳`)
    );
    c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));

    if (incompleteList.length > 0) {
      c.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`### ⏳ Incomplete Quests (${incompleteList.length})\n${incompleteList.slice(0, 15).join("\n")}${incompleteList.length > 15 ? `\n> *...and ${incompleteList.length - 15} more*` : ""}`)
      );
    }

    if (completedList.length > 0) {
      c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
      c.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`### ✅ Completed Quests (${completedList.length})\n${completedList.slice(0, 15).join("\n")}${completedList.length > 15 ? `\n> *...and ${completedList.length - 15} more*` : ""}`)
      );
    }

    c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
    c.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# ${SadieTheme.emojis.max} Use \`!questall\` to complete all remaining incomplete quests!`)
    );

    return interaction.editReply({ components: [c], flags: MessageFlags.IsComponentsV2 } as any);
  }
}
