import {
  ChatInputCommandInteraction,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} from "discord.js";
import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { CustomClient } from "../../core/customClient.js";
import { SadieTheme } from "../../config/theme.js";

export default class QuestlistCommand extends SlashCommand {
  public name        = "questlist";
  public description = "List all Discord quests and their support status";
  public options     = [];

  public async execute({ interaction, client }: {
    interaction: ChatInputCommandInteraction;
    client: CustomClient;
  }): Promise<any> {
    const supported: string[] = client.questsSupported ?? [];

    const c = new ContainerBuilder().setAccentColor(SadieTheme.colors.primary);

    c.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# <a:emoji_5:1571194469263483051> Quest List`),
      new TextDisplayBuilder().setContent(
        `**${supported.length}** quest type${supported.length !== 1 ? "s" : ""} currently supported.`
      )
    );

    c.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );

    if (supported.length === 0) {
      c.addTextDisplayComponents(
        new TextDisplayBuilder().setContent("> No quests loaded yet — the bot may still be initialising.")
      );
    } else {
      const lines = supported.map(q => `> <a:emoji_7:1571194594400407732> \`${q}\``).join("\n");
      c.addTextDisplayComponents(new TextDisplayBuilder().setContent(lines));
    }

    c.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false)
    );
    c.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text}`)
    );

    const reply = interaction.deferred || interaction.replied
      ? interaction.editReply.bind(interaction)
      : interaction.reply.bind(interaction);

    await reply({ components: [c], flags: MessageFlags.IsComponentsV2 } as any);
  }
}
