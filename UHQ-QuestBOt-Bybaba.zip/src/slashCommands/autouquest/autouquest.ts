import {
  ChatInputCommandInteraction,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} from "discord.js";
import { SlashCommand } from "../../lib/handler/slashCommand.js";
import { autoQuest } from "../../core/stores.js";
import { SadieTheme } from "../../config/theme.js";

export default class AutouquestCommand extends SlashCommand {
  public name        = "autouquest";
  public description = "Auto-complete every new quest the moment it drops";
  public options     = [];

  public async execute({ interaction }: { interaction: ChatInputCommandInteraction }): Promise<any> {
    const wasOn = autoQuest.has(interaction.user.id);
    if (wasOn) autoQuest.delete(interaction.user.id);
    else        autoQuest.add(interaction.user.id);

    const on = !wasOn;
    const c  = new ContainerBuilder().setAccentColor(on ? SadieTheme.colors.primary : SadieTheme.colors.error);

    c.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        on ? "# ❤️‍🔥 Auto-Quest — Enabled" : "# 🌑 Auto-Quest — Disabled"
      ),
      new TextDisplayBuilder().setContent(
        on
          ? "New quests will be completed **automatically** the moment they drop."
          : "Auto-quest has been **turned off**. New quests won't auto-run."
      )
    );
    c.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false)
    );
    c.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# ${SadieTheme.emojis.max} ${SadieTheme.footer.text}`)
    );

    const reply = interaction.deferred || interaction.replied
      ? interaction.editReply.bind(interaction)
      : interaction.reply.bind(interaction);

    await reply({ components: [c], flags: MessageFlags.IsComponentsV2 } as any);
  }
}
