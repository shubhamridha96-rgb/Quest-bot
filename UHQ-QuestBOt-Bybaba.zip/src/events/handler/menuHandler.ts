import { AnySelectMenuInteraction, ClientEvents, ContextMenuCommandInteraction } from "discord.js";
import { baseDiscordEvent } from "../../lib/handler/baseClientEvent.js";
import { simplePayload } from "../../lib/handler/componentsV2.js";
import { cooldown } from "../../core/cooldown.js";
import config from "../../config/config.js";
import { GuildCommandSettings } from "../../entities/guildSettings.js";
import { menuCommand } from "../../lib/handler/menu.js";

export default class menuHandler extends baseDiscordEvent {
    public name: keyof ClientEvents = "interactionCreate";
    public once: boolean = false;
    async executeEvent(interaction: AnySelectMenuInteraction | ContextMenuCommandInteraction<"cached">):Promise<any> {
        if ((!interaction.isContextMenuCommand() && !interaction.isAnySelectMenu()) || !this.client.ready) return;
        const type = interaction.isContextMenuCommand() ? "contextMenu" : "menu";
        const name = interaction.isContextMenuCommand() ? interaction.commandName.toLowerCase() : interaction.customId.toLowerCase();
        const command:menuCommand = this.client.menus.get(name) || this.client.menus.find(e => e.type === type && e.passFilter(interaction)) 
        if (!command) return;
        const guildConfig = interaction.guildId && this.client.guildSettings.get(interaction.guildId) || null
        const lang = guildConfig?.lang || this?.client.config?.defaultLanguage || "en";
        const i18n = this.client.i18n.get(lang);
        const commandKey = command.getCommandKey();

        const replyInteraction = async (content: string, returnEphemeral: Boolean, editReply = false) => {
            const replyied = interaction?.replied == true
            const ephemeral = Boolean(command.hasFlag("ephemeral") && !editReply || returnEphemeral);
            const payload = simplePayload(content, undefined, ephemeral);
            try {
                if (replyied) {
                    await interaction.editReply({ ...payload, components: payload.components } as any);
                } else {
                    await interaction.reply({ ...payload } as any);
                }
            } catch (err) {
                this.logger.error(`Failed to reply to interaction ${interaction.id}:`, err);
            }
        };
        const guildCommandConfig = guildConfig?.commands?.[commandKey] as GuildCommandSettings;
        const disabled = guildCommandConfig?.enabled !== undefined
            ? !guildCommandConfig.enabled
            : !command.enabled;

        if (disabled) return replyInteraction(i18n.t("commandDisabled"), true);
        if (command.hasFlag("onlyGuild") && !interaction.guildId && !command.hasFlag("onlyDm")) {
            return replyInteraction(i18n.t("guildOnly"), true);
        }
        if (command.hasFlag("onlyDm") && interaction.guild && !command.hasFlag("onlyGuild")) {
            return replyInteraction(i18n.t("dmOnly"), true);
        }
        if (command.hasFlag("devOnly") && !config?.developers?.includes(interaction.user.id)) {
            return replyInteraction(i18n.t("devOnly"), true);
        }
        const commandCd = command.getCooldown();
        const cdKey = command.hasFlag("userCooldown") ? `${commandKey}-${interaction.user.id}` : `${interaction.user.id}-${commandKey}-${interaction.guild?.id || "dm"}`;
        const dbCd = command.hasFlag("cooldownDatabase");

        const cd = await cooldown.get(cdKey, dbCd);

        if (cd) {
            const remaining = this.client.formatDuration(cd.getRemaining(),lang);
            return replyInteraction(i18n.t("cooldown", { time: remaining }), true);
        }

        if (command.hasFlag("ownerOnly") && !config?.developers?.includes(interaction.user.id)) {
            return replyInteraction(i18n.t("developerOnly"), true);
        }
        if (interaction.guild && interaction.inCachedGuild()) {
            const { channel, guild, member, user } = interaction;

            if (!command.isAllowedGuild(guild.id)) return replyInteraction(i18n.t("notAllowedGuild"), true)
            if (command.hasFlag("ownerOnly") && user.id !== guild.ownerId) {
                return replyInteraction(i18n.t("ownerOnly"), true);
            }
            const botPerms = command.getBotPermissions();
            if (!guild.members.me.permissions.has(botPerms)) {
                return replyInteraction(i18n.t("noPermissionBot", {
                    permissions: command.bot_permissions.join(","),
                }), true);
            }
            const cmdConfig: GuildCommandSettings = guildCommandConfig ?? {} as GuildCommandSettings;

            const isOwner = user.id === guild.ownerId;
            const allowedRoles = cmdConfig.allowedRoles ?? command.allowedRoles ?? [];
            const disabledRoles = cmdConfig.disabledRoles ?? [];
            const allowedChannels = cmdConfig.allowedChannels ?? command.allowedChannels ?? [];
            const disabledChannels = cmdConfig.disabledChannels ?? [];
            const permissions = cmdConfig.allowedPermissions ?? command.permissions ?? [];
            const resolvedPerms = command.reslovePermissions(permissions as any);
            if (disabledChannels.includes(channel.id) || (allowedChannels.length && !allowedChannels.includes(channel.id))) {
                return replyInteraction(i18n.t("commandDisabledInChannel", {
                    channel: channel.toString(),
                }), true);
            }
            const memberRoles = member.roles.cache;
            const hasAllowedRole = allowedRoles.some(role => memberRoles.has(role));
            const hasDisallowedRole = disabledRoles.some(role => memberRoles.has(role));

            if (hasDisallowedRole && !hasAllowedRole) {
                return replyInteraction(i18n.t("commandDisabledInRole"), true);
            }
            const hasPermission = permissions.length === 0 && allowedRoles.length > 0 ? hasAllowedRole || isOwner : member.permissions.has(resolvedPerms) || hasAllowedRole || isOwner

            const permString = !permissions[0] ? `<@&${allowedRoles[0]}>` : permissions.map(e => `\`${e.trim()}\``).join(", ");
            if (!hasPermission) {
                return replyInteraction(i18n.t("noPermmisionUser", {
                    permissions: permString,
                }), true);
            }
        }
        try {
            cooldown.create(cdKey, commandCd, dbCd);
            if (!command.hasFlag("noReply")) {
                await interaction.deferReply({
                    flags: command.hasFlag("ephemeral") ? ["Ephemeral"] : [],
                } as any)
            }

            await command.execute({
                interaction,
                i18n,
                client: this.client,
                lang,
                guildConfig,
            });

        } catch (err) {

            replyInteraction(i18n.t("commandError"), true);
        }
    }

}
