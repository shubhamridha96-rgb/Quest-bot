import { ClientEvents, Message, OmitPartialGroupDMChannel } from "discord.js";
import { baseDiscordEvent } from "../../lib/handler/baseClientEvent.js";
import config from "../../config/config.js";
import { cooldown } from "../../core/cooldown.js";
import { simplePayload, V2_FLAG } from "../../lib/handler/componentsV2.js";
import { GuildCommandSettings } from "../../entities/guildSettings.js";

export default class messageHandler extends baseDiscordEvent {
    public name: keyof ClientEvents = "messageCreate";
    public once: boolean = false;

    async executeEvent(message: OmitPartialGroupDMChannel<Message<boolean>>): Promise<any> {
        if (!message.content || message.author.bot || !this.client.ready) return;
        const replyMessage = async (content: string) => {
            const payload = simplePayload(content);
            return message.reply({
                ...payload,
                allowedMentions: { repliedUser: true },
            } as any).catch(err => {
                this.logger.error(`Failed to reply to message ${message.id}:`, err);
            });

        };
        const guildConfig = message.guildId && this.client.guildSettings.get(message.guildId) || null
        const lang = guildConfig?.lang || this?.client.config?.defaultLanguage || "en";
        const i18n = this.client.i18n.get(lang);
        const configuredPrefix = guildConfig?.prefix || config?.prefix || "!";
        const validPrefixes = Array.from(new Set([configuredPrefix, "!"]));
        const usedPrefix = validPrefixes.find(p => message.content.startsWith(p));
        if (!usedPrefix) return;
        const prefix = usedPrefix;
        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const cmd = args.shift()?.toLowerCase();
        const command = this.client.messageCommands.get(cmd) || this.client.messageCommands.find(e => e?.hasAlias(cmd));
        if (!command) {
            const slashCmd = this.client.slashCommands.get(cmd) || this.client.slashCommands.find(s => s.name === cmd);
            if (slashCmd) {
                let lastReplyMsg: any = null;
                const mockInteraction: any = {
                    user: message.author,
                    member: message.member,
                    guild: message.guild,
                    guildId: message.guildId,
                    channel: message.channel,
                    channelId: message.channelId,
                    client: this.client,
                    createdTimestamp: message.createdTimestamp,
                    id: message.id,
                    replied: false,
                    deferred: false,
                    reply: async (payload: any) => {
                        mockInteraction.replied = true;
                        lastReplyMsg = await message.reply(payload).catch(() => null);
                        return lastReplyMsg;
                    },
                    editReply: async (payload: any) => {
                        if (lastReplyMsg && typeof lastReplyMsg.edit === "function") {
                            return lastReplyMsg.edit(payload).catch(() => null);
                        }
                        lastReplyMsg = await message.reply(payload).catch(() => null);
                        return lastReplyMsg;
                    },
                    followUp: async (payload: any) => {
                        return (message.channel as any).send(payload).catch(() => null);
                    },
                    deferReply: async () => {
                        mockInteraction.deferred = true;
                    },
                    deleteReply: async () => {
                        if (lastReplyMsg && typeof lastReplyMsg.delete === "function") {
                            return lastReplyMsg.delete().catch(() => null);
                        }
                        return message.delete().catch(() => null);
                    },
                    fetchReply: async () => {
                        return lastReplyMsg || message;
                    },
                    options: {
                        getString: (_name: string) => args[0] || null,
                        getUser: (_name: string) => message.mentions.users.first() || null,
                        getInteger: (_name: string) => args[0] ? parseInt(args[0]) : null,
                        getNumber: (_name: string) => args[0] ? parseFloat(args[0]) : null,
                        getBoolean: (_name: string) => args[0] === "true",
                        get: (_name: string) => args[0] ? { value: args[0] } : null,
                    }
                };
                try {
                    await slashCmd.execute({
                        interaction: mockInteraction,
                        client: this.client,
                        i18n,
                        guildConfig,
                    });
                } catch (err) {
                    this.logger.error(`Failed to execute bridged command ${cmd}:`, err);
                }
                return;
            }
            return;
        }
        const commandKey = command.getCommandKey();
        const commandCd = command.getCooldown();
        const cdKey = command.hasFlag("userCooldown") ? `${commandKey}-${message.author.id}` : `${message.author.id}-${commandKey}-${message.guild?.id || "dm"}`;
        const dbCd = command.hasFlag("cooldownDatabase");
        const cd = await cooldown.get(cdKey, dbCd);
        const argsCheck = command.greaterThanMinArgs(args.length) && command.lessThanMaxArgs(args.length);
        if (!command.enabled) return replyMessage(i18n.t("commandDisabled"));
        if (command.hasFlag("onlyGuild") && !message.guild && !command.hasFlag("onlyDm")) {
            return replyMessage(i18n.t("guildOnly"));
        }
        else if (command.hasFlag("onlyDm") && message.guild && !command.hasFlag("onlyGuild")) {
            return replyMessage(i18n.t("dmOnly"));
        }

        if (!argsCheck) return replyMessage(i18n.t("badUsage", { usage: command.getUsage(prefix) }));

        if (cd) {
            const remaining = this.client.formatDuration(cd.getRemaining(),lang);
            return replyMessage(i18n.t("cooldown", { time: remaining }));
        };
        if(command.hasFlag("ownerOnly") && !config?.developers?.includes(message.author.id)) {
            return replyMessage(i18n.t("developerOnly"));
        }

        if (message.guild) {
            const { channel, guild, member, author } = message;
            if(!command.isAllowedGuild(guild.id)) return replyMessage(i18n.t("notAllowedGuild"))
       
            const user = author
            const isOwner = user.id === guild.ownerId;
            if (command.hasFlag("ownerOnly") && !isOwner && !config?.developers?.includes(user.id)) {
                return replyMessage(i18n.t("ownerOnly"));
            }
            const botPerms = command.getBotPermissions();
            if (!guild.members.me.permissions.has(botPerms)) {
                return replyMessage(i18n.t("noPermissionBot", {
                    permissions: command.bot_permissions.join(","),
                }));
            }
            const guildCommandConfig = guildConfig?.commands?.[commandKey];
            const cmdConfig: GuildCommandSettings = guildCommandConfig ?? {} as GuildCommandSettings;
            const allowedRoles = cmdConfig.allowedRoles ?? command.allowedRoles ?? [];
            const disabledRoles = cmdConfig.disabledRoles ?? [];
            const allowedChannels = cmdConfig.allowedChannels ?? command.allowedChannels ?? [];
            const disabledChannels = cmdConfig.disabledChannels ?? [];
            const permissions = cmdConfig.allowedPermissions ?? command.permissions ?? [];
            const resolvedPerms = command.reslovePermissions(permissions as any);
            if (disabledChannels.includes(channel.id) || (allowedChannels.length && !allowedChannels.includes(channel.id))) {
                return 
            }
            const memberRoles = member.roles.cache;
            const hasAllowedRole = allowedRoles.some(role => memberRoles.has(role));
            const hasDisallowedRole = disabledRoles.some(role => memberRoles.has(role));

            if (hasDisallowedRole && !hasAllowedRole) {
                return replyMessage(i18n.t("commandDisabledInRole"));
            }
            const hasPermission = permissions.length === 0 && allowedRoles.length > 0 ? hasAllowedRole || isOwner : member.permissions.has(resolvedPerms) || hasAllowedRole || isOwner

            const permString = !permissions[0] ? `<@&${allowedRoles[0]}>` : permissions.map(e => `\`${e.trim()}\``).join(", ");
            if (!hasPermission) {
                return replyMessage(i18n.t("noPermmisionUser", {
                    permissions: permString,
                }));
            }
        }
        try {
            cooldown.create(cdKey, commandCd, dbCd);
            if (command.hasFlag("deleteMessage")) {
                if (message.guild && message.guild.members.me.permissions.has("ManageMessages")) {
                    await message.delete().catch(err => {
                        this.logger.error(`Failed to delete message ${message.id}:`, err);
                    });
                }
            }

            await command.execute({
                message,
                i18n,
                client: this.client,
                lang,
                args,
                guildConfig,
            });
            this.logger.info(`Executed command ${cmd} for user ${message.author.tag} successfully.`);
        } catch (err) {
            this.logger.error(`Failed to execute command ${cmd} for message ${message.id}:`, err);
            replyMessage(i18n.t("commandError"));
        }

    }

}
